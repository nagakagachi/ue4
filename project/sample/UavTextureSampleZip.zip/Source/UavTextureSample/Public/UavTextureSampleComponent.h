// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"


#include "RHI.h"
#include "RenderResource.h"
#include "RenderUtils.h"
#include "Containers/DynamicRHIResourceArray.h"


#include "Kismet/BlueprintFunctionLibrary.h"
#include "Engine/TextureRenderTarget2D.h"


#include "UavTextureSampleComponent.generated.h"



// UAV�Ƃ��ė��p�\��RW�e�N�X�`��UObject
// ���\�[�X�����p�����[�^�Ƃ���UAV��������
// UAV�̎��ۂ̍쐬�͂��̃I�u�W�F�N�g�̗��p�������s����
UCLASS(BlueprintType)
class UNglRWTextureRenderTarget2D : public UTextureRenderTarget2D
{
	GENERATED_UCLASS_BODY()

public:
	virtual ~UNglRWTextureRenderTarget2D();

	FUnorderedAccessViewRHIRef uav_;
};


// �\�����o�b�t�@�f�[�^�z��
template<typename ElementType>
class TStructuredBufferData
{
	TResourceArray<ElementType, DEFAULT_ALIGNMENT> Data;

public:

	/**
	* Constructor
	* @param InNeedsCPUAccess - true if resource array data should be CPU accessible
	*/
	TStructuredBufferData(bool InNeedsCPUAccess = false)
		: Data(InNeedsCPUAccess)
	{
	}
	virtual ~TStructuredBufferData()
	{
	}

	/**
	* Resizes the vertex data buffer, discarding any data which no longer fits.
	*
	* @param num - The number of vertices to allocate the buffer for.
	* @param BufferFlags - Flags to define the expected behavior of the buffer
	*/
	void ResizeBuffer(uint32 num, EResizeBufferFlags BufferFlags = EResizeBufferFlags::None)
	{
		if ((uint32)Data.Num() < num)
		{
			// Enlarge the array.
			if (!EnumHasAnyFlags(BufferFlags, EResizeBufferFlags::AllowSlackOnGrow))
			{
				Data.Reserve(num);
			}

			Data.AddUninitialized(num - Data.Num());
		}
		else if ((uint32)Data.Num() > num)
		{
			// Shrink the array.
			bool AllowShinking = !EnumHasAnyFlags(BufferFlags, EResizeBufferFlags::AllowSlackOnReduce);
			Data.RemoveAt(num, Data.Num() - num, AllowShinking);
		}
	}

	void Empty(uint32 num)
	{
		Data.Empty(num);
	}

	bool IsValidIndex(uint32 Index)
	{
		return Data.IsValidIndex(Index);
	}

	/**
	* @return stride of the vertex type stored in the resource data array
	*/
	uint32 GetStride() const
	{
		return sizeof(ElementType);
	}
	/**
	* @return uint8 pointer to the resource data array
	*/
	uint8* GetDataPointer()
	{
		return (uint8*)Data.GetData();
	}

	/**
	* @return resource array interface access
	*/
	FResourceArrayInterface* GetResourceArray()
	{
		return &Data;
	}
	/**
	* Serializer for this class
	*
	* @param Ar - archive to serialize to
	* @param B - data to serialize
	*/
	void Serialize(FArchive& Ar)
	{
		Data.TResourceArray<ElementType, DEFAULT_ALIGNMENT>::BulkSerialize(Ar);
	}
	/**
	* Assignment. This is currently the only method which allows for
	* modifying an existing resource array
	*/
	void Assign(const TArray<ElementType>& Other)
	{
		ResizeBuffer(Other.Num());
		if (Other.Num())
		{
			memcpy(GetDataPointer(), &Other[0], Other.Num() * sizeof(ElementType));
		}
	}

	/**
	* Helper function to return the amount of memory allocated by this
	* container.
	*
	* @returns Number of bytes allocated by this container.
	*/
	SIZE_T GetResourceSize() const
	{
		return Data.GetAllocatedSize();
	}

	/**
	* Helper function to return the number of elements by this
	* container.
	*
	* @returns Number of elements allocated by this container.
	*/
	virtual int32 Num() const
	{
		return Data.Num();
	}

	bool GetAllowCPUAccess() const
	{
		return Data.GetAllowCPUAccess();
	}
};

// �\�����o�b�t�@
template<typename ElementType>
class FNglStructuredBufferResource : public FRenderResource
{
public:
	FNglStructuredBufferResource()
	{
	}
	virtual ~FNglStructuredBufferResource()
	{
		CleanUp();
	}

	void CleanUp()
	{
		if (bufferData_)
		{
			delete bufferData_;
			bufferData_ = NULL;
		}
	}

	// �������\�[�X����������. �[���N���A.
	void Init(uint32 num, bool enable_uav = false, bool enable_cpu_access = false)
	{
		num_ = num;
		enable_uav_ = enable_uav;
		enable_cpu_access_ = enable_cpu_access;

		AllocateData(enable_cpu_access_);

		bufferData_->ResizeBuffer(num_);

		// �[���N���A
		FMemory::Memset(bufferData_->GetDataPointer(), 0x00, stride_ * num_);
	}
	// CPU���\�[�X�ݒ肵�ď����l�Ƃ��ė��p
	void Init(const TArray<ElementType>& data, bool enable_uav = false, bool enable_cpu_access = false)
	{
		num_ = data.Num();
		enable_uav_ = enable_uav;
		enable_cpu_access_ = enable_cpu_access;
		if (num_)
		{
			AllocateData(enable_cpu_access_);
			check(stride_ == data.GetTypeSize());
			bufferData_->ResizeBuffer(num_);
			FMemory::Memcpy(bufferData_->GetDataPointer(), data.GetData(), stride_ * num_);
		}
	}
	// RnderThread����Ă΂��RHI���\�[�X������
	void InitRHI()
	{
		check(bufferData_);
		FResourceArrayInterface* ResourceArray = bufferData_->GetResourceArray();
		if (ResourceArray->GetResourceDataSize())
		{
			// Create the vertex buffer.
			FRHIResourceCreateInfo CreateInfo(ResourceArray);

			uint32 usage = BUF_Static | BUF_ShaderResource;
			if (enable_uav_)
				usage |= BUF_UnorderedAccess;

			buffer_ = RHICreateStructuredBuffer(stride_, num_ * stride_, usage, CreateInfo);

			srv_ = RHICreateShaderResourceView(buffer_);

			// UAV�A�N�Z�X�������ꍇ�͐���
			if (enable_uav_)
				uav_ = RHICreateUnorderedAccessView(buffer_, false, false);
		}
	}
	// FRenderResource interface.
	virtual void ReleaseRHI() override
	{
		srv_.SafeRelease();
		uav_.SafeRelease();
		buffer_.SafeRelease();
	}

	// getter
	int NumElement() const { return num_; }
	int Stride() const { return stride_; }
	FStructuredBufferRHIRef GetBuffer() { return buffer_; }
	FShaderResourceViewRHIRef GetSrv() { return srv_; }
	FUnorderedAccessViewRHIRef GetUav() { return uav_; }

private:
	void AllocateData(bool bInNeedsCPUAccess)
	{
		CleanUp();

		bufferData_ = new TStructuredBufferData<ElementType>(bInNeedsCPUAccess);
		stride_ = bufferData_->GetStride();
	}

	FStructuredBufferRHIRef buffer_;	// �o�b�t�@�{��
	FShaderResourceViewRHIRef srv_;		// srv
	FUnorderedAccessViewRHIRef uav_;	// uav

	bool	enable_uav_ = false;
	bool	enable_cpu_access_ = false;
	int		num_ = 0;
	int		stride_ = 0;
	TStructuredBufferData<ElementType>* bufferData_ = nullptr;
};




UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class UAVTEXTURESAMPLE_API UUavTextureSampleComponent : public USceneComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UUavTextureSampleComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintPure)
		UNglRWTextureRenderTarget2D* GetRwTexture() const;

	UPROPERTY()
		TArray<UNglRWTextureRenderTarget2D*> rw_tex_;

	UFUNCTION(BlueprintCallable)
	void SetTargetPosition( const FVector& target_position)
	{
		target_position_ = target_position;
	}
	UFUNCTION(BlueprintCallable)
		void SetTargetRadius(float target_radius)
	{
		target_radius_ = target_radius;
	}
	UFUNCTION(BlueprintCallable)
		void SetSimSpaceAabb(const FBox& aabb)
	{
		aabb_ = aabb;
	}
	UFUNCTION(BlueprintPure)
		FBox GetSimSpaceAabb() const
	{
		return aabb_;
	}

	FNglStructuredBufferResource<FVector4>* GetStructuredBuffer(bool is_front)
	{
		const int i = (is_front)? flip_index_ : (1 - flip_index_);
		return &(structured_buffer_[i]);
	}

	FBox GetAabb() const
	{
		return aabb_;
	}

	FVector GetTargetPosition() const
	{
		return target_position_;
	}
	float GetTargetRadius() const
	{
		return target_radius_;
	}
protected:
	void EnqueueDispatchComputeShader();


private:
	int flip_index_ = 0;
	
	FBox aabb_ = FBox(FVector(-100.0f), FVector(100.0f));
	FVector target_position_ = FVector::ZeroVector;
	float	target_radius_ = 200.0f;

	FNglStructuredBufferResource<FVector4>	structured_buffer_[2];
};
