﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "NglShaderIncludePlugin.h"

#include "Modules/ModuleManager.h"

#include "Misc/Paths.h"
#include "ShaderCore.h"

#define LOCTEXT_NAMESPACE "FNglShaderIncludePluginModule"

void FNglShaderIncludePluginModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
	FString ShaderDirectory = FPaths::Combine(FPaths::ProjectDir(), TEXT("Shaders"));

	if (!FPaths::DirectoryExists(ShaderDirectory))
	{
		// directory "ProjectRoot/Shaders" does not exist.
		UE_LOG(LogTemp, Warning, TEXT("    [FNglShaderIncludePluginModule] directory [ProjectRoot/Shaders] does not exist."));
		return;
	}

	if (!AllShaderSourceDirectoryMappings().Contains("/Project"))
	{
		AddShaderSourceDirectoryMapping("/Project", ShaderDirectory);
	}
}

void FNglShaderIncludePluginModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FNglShaderIncludePluginModule, NglShaderIncludePlugin)