/*
	Copyright (c) 2018 Taro Horikawa

	twitter@nagakagachi
*/

#pragma once

#include "CoreMinimal.h"
//#include "ModuleManager.h"
#include "Modules/ModuleManager.h"

class FNglNNModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};