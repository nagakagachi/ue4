﻿/*
	Copyright (c) 2018 Taro Horikawa

	twitter@nagakagachi
*/


#include "NglNeuralNetworkCore.h"

#include <cmath>

namespace
{
	const float GRADIENT_CHECKING_EPSILON = 0.0001;
}

#ifdef UE_BUILD_DEBUG
//#define NGL_DEBUG_NAN_CHECK
#endif

//  Box–Muller's method
//		mu		: Average
//		sigma	: Standard deviation 
float NglMathUtil::NormalRandom(const float mu, const float sigma)
{
	// 1e-6f is a measure against log (0).
	return sigma * FMath::Sqrt(-2.0 * log(FMath::Max(1e-6f, FMath::FRand()))) * cos(2.0 * PI *FMath::FRand()) + mu;
}


// --------------------------------------------------------------------------------------------------------
NglOptimizerMomentumSGD::NglOptimizerMomentumSGD()
{
	Reset();
	momentum_ = 0.9f; // default
}
NglOptimizerMomentumSGD::~NglOptimizerMomentumSGD()
{
}
void NglOptimizerMomentumSGD::Initialize(float momentum)
{
	momentum_ = momentum;
}
void NglOptimizerMomentumSGD::Reset()
{
	moment_.Empty();
}
void NglOptimizerMomentumSGD::SetMomentum(float momentum)
{
	momentum_ = momentum;
}
void NglOptimizerMomentumSGD::operator()(TArray<float>& targetParam, const TArray<float>& paramDelta,
	float paramDeltaRate, float updateRate, float weightDecay)
{
	const int MinSize = FMath::Min(targetParam.Num(), paramDelta.Num());
	if (moment_.Num() != paramDelta.Num())
	{
		moment_.SetNumUninitialized(MinSize);
		NglMathUtil::FillTArray(moment_, 0.0f);
	}
	const float rate = paramDeltaRate * updateRate;
	for (int i = 0; i < MinSize; ++i)
	{
		const float d = std::fmaf(-paramDelta[i], rate, moment_[i] * momentum_);
#ifdef NGL_DEBUG_NAN_CHECK
		if ( isnan(d) || isinf(d) )
		{
			UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglOptimizerMomentumSGD] NaN."));
		}
#endif
		// save moment.	
		moment_[i] = d;

		// update with L2-regularization(SGDW).
		//targetParam[i] += d + (-weightDecay * targetParam[i]);
		targetParam[i] += std::fmaf(-weightDecay, targetParam[i], d);
	}
}
// --------------------------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------------------------
NglOptimizerAdam::NglOptimizerAdam()
{
	Reset();
}
NglOptimizerAdam::~NglOptimizerAdam()
{
}
void NglOptimizerAdam::Initialize(float beta1, float beta2)
{
	SetParam( beta1, beta2 );
}
void NglOptimizerAdam::Reset()
{
	t_ = 0;
	SetParam();
	moment1st_.Empty();
	moment2nd_.Empty();
}
void NglOptimizerAdam::SetParam(float beta1, float beta2)
{
	beta1_ = beta1;
	beta2_ = beta2;
}
void NglOptimizerAdam::operator()(TArray<float>& targetParam, const TArray<float>& paramDelta,
	float paramDeltaRate, float updateRate, float weightDecay)
{
	const float epsilon = 1e-8f;

	const int MinSize = FMath::Min(targetParam.Num(), paramDelta.Num());
	if (moment1st_.Num() != paramDelta.Num())
	{
		moment1st_.SetNumUninitialized(MinSize);
		NglMathUtil::FillTArray(moment1st_, 0.0f);
	}
	if (moment2nd_.Num() != paramDelta.Num())
	{
		moment2nd_.SetNumUninitialized(MinSize);
		NglMathUtil::FillTArray(moment2nd_, 0.0f);
	}

	const unsigned int mask = ~(0x00);
	t_ += (mask!=t_)? 1 : 0;// update time.
	for (int i = 0; i < MinSize; ++i)
	{
		const float delta = paramDelta[i] * paramDeltaRate;
		// update moment1 and moment2
		moment1st_[i] = FMath::Lerp(delta, moment1st_[i], beta1_);
		moment2nd_[i] = FMath::Lerp(delta*delta, moment2nd_[i], beta2_);

		float m1 = moment1st_[i] / (1.0f - FMath::Pow(beta1_, t_));
		float m2 = moment2nd_[i] / (1.0f - FMath::Pow(beta2_, t_));
		
		// update with L2-regularization(AdamW).
		//targetParam[i] = targetParam[i] - ( updateRate * m1/(FMath::Sqrt(m2) + epsilon ) ) - (weightDecay * targetParam[i]);
		float u0 = std::fmaf(-updateRate, m1 / (FMath::Sqrt(m2) + epsilon), targetParam[i]);
		targetParam[i] = std::fmaf(-weightDecay, targetParam[i], u0);

#ifdef NGL_DEBUG_NAN_CHECK
		if (isnan(targetParam[i]) || isinf(targetParam[i]))
		{
			UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglOptimizerAdam] NaN."));
		}
#endif

	}
}
// --------------------------------------------------------------------------------------------------------


// init layer-base buffer. (e.g. input,output and weight buffer. 
void NglNeuralNetworkLayerBase::InitializeBase(unsigned int inputCount, unsigned int outputCount, unsigned int weightCount)
{
	input_.SetNumZeroed( inputCount );
	output_.SetNumZeroed( outputCount );
	weightMatrix_.SetNumZeroed( weightCount );
}

void NglNeuralNetworkLayerBase::OnChangeTrainMode(bool toTrainMode)
{
	if (toTrainMode)
	{
		unsigned int numInput = NumInput();
		unsigned int numOutput = NumOutput();
		unsigned int numWeight = NumWeight();
		// change to Train Mode
		backPropagationGradient_.SetNumZeroed(numInput);
		weightDeltaMatrix_.SetNumZeroed(numWeight);
	}
	else
	{
		// change to Inference Mode
		backPropagationGradient_.Empty();
		weightDeltaMatrix_.Empty();

		optimizerMomentumSGD_.Reset();
		optimizerAdam_.Reset();
	}
}
// getter
unsigned int NglNeuralNetworkLayerBase::NumInput() const
{
	return input_.Num();
}
const float* NglNeuralNetworkLayerBase::GetInput() const
{
	return input_.GetData();
}
float* NglNeuralNetworkLayerBase::GetInput()
{
	return input_.GetData();
}
unsigned int NglNeuralNetworkLayerBase::NumOutput() const
{
	return output_.Num();
}
const float* NglNeuralNetworkLayerBase::GetOutput() const
{
	return output_.GetData();
}
float* NglNeuralNetworkLayerBase::GetOutput()
{
	return output_.GetData();
}
unsigned int NglNeuralNetworkLayerBase::NumWeight() const
{
	return weightMatrix_.Num();
}
const float* NglNeuralNetworkLayerBase::GetWeightPtr() const
{
	return weightMatrix_.GetData();
}
float* NglNeuralNetworkLayerBase::GetWeightPtr()
{
	return weightMatrix_.GetData();
}
const TArray<float>& NglNeuralNetworkLayerBase::GetWeight() const
{
	return weightMatrix_;
}
TArray<float>& NglNeuralNetworkLayerBase::GetWeight()
{
	return weightMatrix_;
}
float NglNeuralNetworkLayerBase::GetWeightAtIndex(unsigned int index) const
{
	if (NumWeight() > index)
	{
		return weightMatrix_[index];
	}
	return 0.0f;
}
// set weight directly. isForce is force set even if different num of weight.
void NglNeuralNetworkLayerBase::SetWeight(const float* weightArray, unsigned int numWeight, bool isForce)
{
	if (NumWeight() != numWeight && !isForce)
		return;

	unsigned int num = FMath::Min(NumWeight(), numWeight);
	memcpy(weightMatrix_.GetData(), weightArray, num * sizeof(float));
}
void NglNeuralNetworkLayerBase::SetWeightAtIndex(unsigned int index, float weight)
{
	if (NumWeight() > index)
	{
		weightMatrix_[index] = weight;
	}
}

void NglNeuralNetworkLayerBase::Forward(const TArray<float>& input)
{
	Forward(input.GetData(), input.Num());
}

void NglNeuralNetworkLayerBase::UpdateWeight(int miniBatchSize, float learningRate, float learningMomentum, float regularizationRate)
{
	if (!IsTrainMode())
		return;

	const float miniBatchDiv = 1.0f / FMath::Max( 1.0f, static_cast<float>(miniBatchSize) );

	// optimize
#if 1
	// Adam
	optimizerAdam_(weightMatrix_, weightDeltaMatrix_, miniBatchDiv, learningRate, regularizationRate);
#else
	// Momentum SGD
	optimizerMomentumSGD_.SetMomentum(learningMomentum);
	optimizerMomentumSGD_(weightMatrix_, weightDeltaMatrix_, miniBatchDiv, learningRate, regularizationRate);
#endif

	// clear weight delta.
	NglMathUtil::FillTArray( weightDeltaMatrix_, 0.0f );

#ifdef NGL_DEBUG_NAN_CHECK
	for (unsigned int i = 0; i < (NumWeight()); ++i)
	{
		if (isnan(weightDeltaMatrix_[i]) || isinf(weightDeltaMatrix_[i]))
			UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglNeuralNetworkLayerBase::UpdateWeight] NaN WeightDelta."));
		if (isnan(weightMatrix_[i]) || isinf(weightMatrix_[i]))
			UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglNeuralNetworkLayerBase::UpdateWeight] NaN Weight."));
	}
#endif

}

// calc L2 Regularization Cost.
float NglNeuralNetworkLayerBase::CalcL2RegularizationCost(float regularizationRate) const
{
	float cost = 0.0;
	const float* w = GetWeightPtr();
	for (unsigned int i = 0; i < (NumWeight()); ++i)
	{
		cost += w[i] * w[i];
	}
	return (cost * regularizationRate);
}
// get backpropagation gradient for prev layer.
const float* NglNeuralNetworkLayerBase::GetBackPropagationGradient() const
{
	if (!IsTrainMode())
		return NULL;
	return backPropagationGradient_.GetData();
}
unsigned int NglNeuralNetworkLayerBase::NumBackPropagationGradient() const
{
	if (!IsTrainMode())
		return 0;
	return backPropagationGradient_.Num();
}
float NglNeuralNetworkLayerBase::GetWeightGradientAtIndex(unsigned int index) const
{
	if (!IsTrainMode())
		return 0.0f;
	if (static_cast<unsigned int>(weightDeltaMatrix_.Num()) > index)
	{
		return weightDeltaMatrix_[index];
	}

	return 0.0f;
}




//--------------------------------------------------------

NglActivationLayer::NglActivationLayer()
{
}
NglActivationLayer::~NglActivationLayer()
{
}
// init layer memory
// set neuron activation functor
bool NglActivationLayer::Initialize(unsigned int numInput)
{
	if (0 >= numInput)
		return false;

	InitializeBase( numInput, numInput, numInput);

	// default is Inference.
	SetToInferenceMode();
	return true;
}
// Call at change mode. Train-Mode is True, Inference-Mode is False.
// ネットワークの学習モードと推論モードを切り替え. デフォルトはメモリ使用量の少ない推論モード
// change network mode with Train or Inference. default is Inference for reasons of low memory usage.
void NglActivationLayer::OnChangeTrainMode(bool toTrainMode)
{
	NglNeuralNetworkLayerBase::OnChangeTrainMode(toTrainMode);
	if (toTrainMode)
	{
		outputDifferential_.SetNumZeroed(NumInput());
	}
	else
	{
		outputDifferential_.Empty();
	}
}

// calc layer neuron activity with forward
void NglActivationLayer::Forward(const float* input, unsigned int size)
{
	const bool isTrain = IsTrainMode();
	// set input
	float* inputBuffer = GetInput();
	unsigned int numAcceptInput = NumInput();
	const unsigned int minNum = FMath::Min(numAcceptInput, size);
	memcpy(inputBuffer, input, sizeof(float) * minNum);
	// zero fill
	for (unsigned int i = minNum; i < numAcceptInput; ++i)
		inputBuffer[i] = 0.0f;

	for ( unsigned int i = 0; i < numAcceptInput; ++i)
	{
		// Bias
		float v = GetWeightPtr()[i] + inputBuffer[i];
		NglDualNumber activate = Activation( v );

		GetOutput()[i] = activate.Value();
		// remain grad
		if (isTrain)
			outputDifferential_[i] = activate.Differential();

#ifdef NGL_DEBUG_NAN_CHECK
		// check output NaN.h
		{
			const float o = activate.Value();
			if (isnan(o) || isinf(o))
				UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglActivationLayer::Forward] NaN Output."));
			const float od = activate.Differential();
			if (isnan(od) || isinf(od))
				UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglActivationLayer::Forward] NaN Output Differential."));
		}
#endif
	}
}
// BackPropagation. add learcning delta to update-matrix. practical update is UpdateWeight().
// 逆伝搬. 引数は出力側から伝搬してきた勾配ベクトル( レイヤの出力ニューロン数と一致 )
// 重み行列の更新値にデルタを足しこみ、前のレイヤへ伝搬する勾配を計算する.
// 実際の重み行列の更新はUpdateWeight()を実行することで処理される.
void NglActivationLayer::BackPropagation(const float* backPropGradient, unsigned int size)
{
	const unsigned int minSize = FMath::Min(size, (unsigned int)NumInput());

	// clear backprop grad
	for (int i = 0; i < backPropagationGradient_.Num(); ++i)
		backPropagationGradient_[i] = 0.0f;

	for (unsigned int i = 0; i < minSize; ++i)
	{
		float delta = backPropGradient[i] * outputDifferential_[i];

		backPropagationGradient_[i] += delta;
		weightDeltaMatrix_[i] += delta;

#ifdef NGL_DEBUG_NAN_CHECK
		if (isnan(delta) || isinf(delta))
			UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglActivationLayer::BackPropagation] NaN."));
#endif
	}
}
// apply weight delta to weight matrix that calculated by backprop.
// ignore activation layer bias.
void NglActivationLayer::UpdateWeight(int miniBatchSize, float learningRate, float momentum, float regularizationRate)
{
	// regularization rate Zero.
	// 活性化層のバイアスは正則化項に含めないため係数をゼロにする.
	NglNeuralNetworkLayerBase::UpdateWeight(miniBatchSize, learningRate, momentum, 0.0 );
}
// calc Regularization Cost.
// ignore activation layer bias.
float NglActivationLayer::CalcL2RegularizationCost(float regularizationRate) const
{
	// regularization rate Zero.
	// 活性化層のバイアスは正則化項に含めないため係数をゼロにする.
	return NglNeuralNetworkLayerBase::CalcL2RegularizationCost( 0.0 );
}


//--------------------------------------------------------

//--------------------------------------------------------
// Softmax層
NglSoftmaxLayer::NglSoftmaxLayer()
{
}
NglSoftmaxLayer::~NglSoftmaxLayer()
{
}
// init layer memory
bool NglSoftmaxLayer::Initialize(unsigned int numInput)
{
	if (0 >= numInput)
		return false;
	InitializeBase(numInput, numInput, 0);
									// default is Inference.
	SetToInferenceMode();

	return true;
}
void NglSoftmaxLayer::OnChangeTrainMode(bool toTrainMode)
{
	NglNeuralNetworkLayerBase::OnChangeTrainMode(toTrainMode);
	if (toTrainMode)
	{
		// numInput * numInput matrix.
		// 内部的には全結合のようなものであるため、すべての出力に対するすべての入力の微分を保持する
		outputDifferential_.SetNumZeroed(NumInput() * NumInput());
	}
	else
	{
		outputDifferential_.Empty();
	}
}

// calc layer neuron activity with forward
void NglSoftmaxLayer::Forward(const float* input, unsigned int size)
{
	// set input
	float* inputBuffer = GetInput();
	unsigned int numInput = NumInput();

	const unsigned int minNum = FMath::Min(numInput, size);
	memcpy(inputBuffer, input, sizeof(float) * minNum);
	// zero fill
	for (unsigned int i = minNum; i < numInput; ++i)
		inputBuffer[i] = 0.0f;

	// find max fot stable softmax.
	int maxInputIndex = -1;
	float maxInput = 0.0f;
	for (unsigned int i = 0; i < numInput; ++i)
	{
		if (0 > maxInputIndex || maxInput < inputBuffer[i])
		{
			maxInputIndex = i; maxInput = inputBuffer[i];
		}
	}

	// calc exp
	float sumExp = 0.0f;
	for (unsigned int i = 0; i < numInput; ++i)
	{
		// subtract maxInput for stability.
		GetOutput()[i] = FMath::Exp(inputBuffer[i] - maxInput);
		sumExp += GetOutput()[i];
	}

	// calc output probability.
	if (0.0f >= sumExp)
		sumExp = 1.0f;
	float divExp = 1.0f / sumExp;
	for (unsigned int i = 0; i < numInput; ++i)
	{
		GetOutput()[i] = GetOutput()[i] * divExp;
	}

	// derivative
	if (IsTrainMode())
	{
		for (unsigned int i = 0; i < numInput; ++i)
		{
			// 総和で割っているため, 勾配としてはすべての出力側の影響を足し合わせる
			// https://eli.thegreenplace.net/2016/the-softmax-function-and-its-derivative/
			for (unsigned int j = 0; j < numInput; ++j)
			{
				float isSameElem = (i == j) ? 1.0f : 0.0f;
				// sum derivative for j respect to i
				outputDifferential_[ i * numInput + j ] = GetOutput()[i] * (isSameElem - GetOutput()[j]);
			}
		}
	}

#ifdef NGL_DEBUG_NAN_CHECK
	// check output NaN.
	for (unsigned int i = 0; i < NumOutput(); ++i)
	{
		const float o = GetOutput()[i];
		if (isnan(o) || isinf(o))
			UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglSoftmaxLayer::Forward] NaN Output."));
	}
#endif
}
void NglSoftmaxLayer::BackPropagation(const float* backPropGradient, unsigned int size)
{
	if (!IsTrainMode())
		return;

	// clear backprop grad
	for (int i = 0; i < backPropagationGradient_.Num(); ++i)
		backPropagationGradient_[i] = 0.0f;

	// 一応サイズチェック
	const unsigned int numOutput = FMath::Min(size, NumOutput());

	for (unsigned int i = 0; i < NumInput(); ++i)
	{
		for (unsigned int j = 0; j < numOutput; ++j)
		{
			backPropagationGradient_[i] = 
				std::fmaf(backPropGradient[j], outputDifferential_[i * NumInput() + j], backPropagationGradient_[i]);
		}
	}
}
//--------------------------------------------------------


//--------------------------------------------------------
// 全結合層
NglAffineLayer::NglAffineLayer()
{
}
NglAffineLayer::~NglAffineLayer()
{
}
// init layer memory
bool NglAffineLayer::Initialize(unsigned int numInput, unsigned int numOutput)
{
	if (0 >= numInput || 0 >= numOutput)
		return false;

	InitializeBase(numInput, numOutput, numInput * numOutput);

	// default is Inference.
	SetToInferenceMode();

	return true;
}
void NglAffineLayer::OnChangeTrainMode(bool toTrainMode)
{
	NglNeuralNetworkLayerBase::OnChangeTrainMode(toTrainMode);
}


// calc layer neuron activity with forward
void NglAffineLayer::Forward(const float* input, unsigned int size)
{
	// set input
	float* inputBuffer = GetInput();
	unsigned int numInput = NumInput();
	unsigned int numOutput = NumOutput();

	const unsigned int minNum = FMath::Min(numInput, size);
	memcpy(inputBuffer, input, sizeof(float) * minNum);
	// zero fill
	for (unsigned int i = minNum; i < numInput; ++i)
		inputBuffer[i] = 0.0f;

	for (unsigned int m = 0; m < numOutput; ++m)
	{
		const float* W = GetWeightPtr() + (numInput * m);
		float Wx = 0.0f;
		for (unsigned int n = 0; n < numInput; ++n)
		{
			Wx = std::fmaf( W[n], inputBuffer[n], Wx);
		}
		GetOutput()[m] = Wx;
	}

#ifdef NGL_DEBUG_NAN_CHECK
	// check output NaN.
	for (unsigned int i = 0; i < NumOutput(); ++i)
	{
		const float o = GetOutput()[i];
		if (isnan(o) || isinf(o))
			UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglAffineLayer::Forward] NaN Output."));
	}
#endif
}
// 初期値を正規分布で設定
void NglAffineLayer::InitializeWeightWithNormalDistribution()
{
	float m = 0.0;
	float standardDeviation = FMath::Sqrt(2.0 / NumInput());

	for (unsigned int j = 0; j < NumOutput(); ++j)
	{
		for (unsigned int i = 0; i < NumInput(); ++i)
		{
			//  "He" initialization
			float z = NglMathUtil::NormalRandom( m, standardDeviation );
			GetWeightPtr()[i + j * NumInput()] = z;

#ifdef NGL_DEBUG_NAN_CHECK
			if (isnan(z) || isinf(z))
				UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglAffineLayer::InitializeWeightWithNormalDistribution] NaN Weight."));
#endif
		}
	}
}
void NglAffineLayer::BackPropagation(const float* backPropGradient, unsigned int size)
{
	if (!IsTrainMode())
		return;

	// clear backprop grad
	for (int i = 0; i < backPropagationGradient_.Num(); ++i)
		backPropagationGradient_[i] = 0.0f;

	// 一応サイズチェック
	const unsigned int minSize = FMath::Min(size, NumOutput());

	for (unsigned int i = 0; i < NumInput(); ++i)
	{
		for (unsigned int o = 0; o < minSize; ++o)
		{
			unsigned int weightIndex = i + (o * NumInput());

			// backprop grad
			backPropagationGradient_[i] = std::fmaf(backPropGradient[o], GetWeightPtr()[weightIndex], backPropagationGradient_[i]);

			// weight delta
			weightDeltaMatrix_[weightIndex] = std::fmaf(backPropGradient[o], GetInput()[i], weightDeltaMatrix_[weightIndex]);
		}
	}
}
//--------------------------------------------------------


//--------------------------------------------------------
NglGruLayer::NglGruLayer()
{
}
NglGruLayer::~NglGruLayer()
{
}

// init layer memory
// set neuron activation functor
bool NglGruLayer::Initialize(unsigned int numInput, unsigned int numOutput)
{
	if (0 >= numInput || 0 >= numOutput)
		return false;


	gateInOutSize_[UPDATE_INPUT] = { numInput, numOutput };
	gateInOutSize_[RESET_INPUT] = { numInput, numOutput };
	gateInOutSize_[CANDIDATE_INPUT] = { numInput, numOutput };
	// reccurent weight size euqual output size.
	// 再帰の重みは出力に掛け合わせて出力と同じ次元に写像するのて出力数*出力数
	gateInOutSize_[UPDATE_RECURRENT] = { numOutput, numOutput };
	gateInOutSize_[RESET_RECURRENT] = { numOutput, numOutput };
	gateInOutSize_[CANDIDATE_RECURRENT] = { numOutput, numOutput };

	// weight size and offset index.
	// 各種重みのサイズと開始インデックス
	unsigned int sumNumWeight = 0;
	for (int i = 0; i < EWEIGHT_KIND_MAX; ++i)
	{
		weightMatrixHeadArray_[i] = sumNumWeight;
		weightMatrixSizeArray_[i] = gateInOutSize_[i].numInput_ * gateInOutSize_[i].numOutput_;
		sumNumWeight += weightMatrixSizeArray_[i];
	}

	InitializeBase(numInput, numOutput, sumNumWeight);

	// Work Buffer.
	// GRUの作業用バッファ
	outputPrev_.SetNumZeroed(NumOutput());
	outputUpdateGate_.SetNumZeroed(NumOutput());
	outputResetGate_.SetNumZeroed(NumOutput());
	outputCandidateGate_.SetNumZeroed(NumOutput());

	// default is Inference.
	SetToInferenceMode();

	return true;
}

// calc layer neuron activity with forward
void NglGruLayer::Forward(const float* input, unsigned int size)
{
	float* inputBuffer = GetInput();
	unsigned int numInput = NumInput();
	unsigned int numOutput = NumOutput();

	const unsigned int minNum = FMath::Min(numInput, size);
	memcpy(inputBuffer, input, sizeof(float) * minNum);
	// zero fill
	for (unsigned int i = minNum; i < numInput; ++i)
		inputBuffer[i] = 0.0f;

	float* weightBuffer = GetWeightPtr();

	// update gate
	for ( unsigned int i = 0; i < NumGateOutput(UPDATE_INPUT); ++i )
	{
		const unsigned int WHead = GetGateWeightHeadIndex(UPDATE_INPUT);
		const unsigned int UHead = GetGateWeightHeadIndex(UPDATE_RECURRENT);
		const unsigned int inputDim = NumGateInput(UPDATE_INPUT);
		const unsigned int recurrentDim = NumGateInput(UPDATE_RECURRENT);

		float wx = 0.0f;
		for (unsigned int j = 0; j < inputDim; ++j)
		{
			wx = std::fmaf( inputBuffer[j], weightBuffer[WHead + (j + i * inputDim)], wx);
		}
		float uh = 0.0f;
		for (unsigned int j = 0; j < recurrentDim; ++j)
		{
			uh = std::fmaf( outputPrev_[j], weightBuffer[UHead + (j + i * recurrentDim)], uh);
		}

		outputUpdateGate_[i] = NglDualNumber::sigmoid(NglDualNumber( wx + uh ).DerivativeRespect());
	}

	// reset gate
	for (unsigned int i = 0; i < NumGateOutput(RESET_INPUT); ++i)
	{
		const unsigned int WHead = GetGateWeightHeadIndex(RESET_INPUT);
		const unsigned int UHead = GetGateWeightHeadIndex(RESET_RECURRENT);
		const unsigned int inputDim = NumGateInput(RESET_INPUT);
		const unsigned int recurrentDim = NumGateInput(RESET_RECURRENT);

		float wx = 0.0f;
		for (unsigned int j = 0; j < inputDim; ++j)
		{
			wx = std::fmaf(inputBuffer[j], weightBuffer[WHead + (j + i * inputDim)], wx);
		}
		float uh = 0.0f;
		for (unsigned int j = 0; j < recurrentDim; ++j)
		{
			uh = std::fmaf(outputPrev_[j], weightBuffer[UHead + (j + i * recurrentDim)], uh);
		}
		outputResetGate_[i] = NglDualNumber::sigmoid(NglDualNumber(wx + uh).DerivativeRespect());
	}

	// candidate gate
	for (unsigned int i = 0; i < NumGateOutput(CANDIDATE_INPUT); ++i)
	{
		const unsigned int WHead = GetGateWeightHeadIndex(CANDIDATE_INPUT);
		const unsigned int UHead = GetGateWeightHeadIndex(CANDIDATE_RECURRENT);
		const unsigned int inputDim = NumGateInput(CANDIDATE_INPUT);
		const unsigned int recurrentDim = NumGateInput(CANDIDATE_RECURRENT);

		float wx = 0.0f;
		for (unsigned int j = 0; j < inputDim; ++j)
		{
			wx = std::fmaf(inputBuffer[j],  weightBuffer[WHead + (j + i * inputDim)], wx);
		}
		float uh = 0.0f;
		for (unsigned int j = 0; j < recurrentDim; ++j)
		{
			uh = std::fmaf(outputResetGate_[j].Value() * outputPrev_[j], weightBuffer[UHead + (j + i * recurrentDim)], uh);
		}
		outputCandidateGate_[i] = NglDualNumber::tanh(NglDualNumber(wx + uh).DerivativeRespect());
	}

	// update output
	for (unsigned int i = 0; i < NumOutput(); ++i)
	{
		GetOutput()[i] = std::fmaf( 
			outputUpdateGate_[i].Value(), 
			outputCandidateGate_[i].Value(),
			(1.0f - outputUpdateGate_[i].Value()) * outputPrev_[i] );
	}
	
	// copy prev
	if (IsInnerStateUpdatable())
		memcpy(outputPrev_.GetData(), GetOutput(), sizeof(*GetOutput())*NumOutput() );

#ifdef NGL_DEBUG_NAN_CHECK
	// check output NaN.
	for (unsigned int i = 0; i < NumOutput(); ++i)
	{
		const float o = GetOutput()[i];
		if (isnan(o) || isinf(o))
			UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglGruLayer::Forward] NaN Output."));
	}
#endif
}

// Call at change mode. Train-Mode is True, Inference-Mode is False.
// ネットワークの学習モードと推論モードを切り替え. デフォルトはメモリ使用量の少ない推論モード
// change network mode with Train or Inference. default is Inference for reasons of low memory usage.
void NglGruLayer::OnChangeTrainMode(bool toTrainMode)
{
	NglNeuralNetworkLayerBase::OnChangeTrainMode(toTrainMode);
	if (toTrainMode)
	{
		resetGateBackPropGradient_.SetNumZeroed(NumGateInput(CANDIDATE_RECURRENT));
	}
	else
	{
		resetGateBackPropGradient_.Empty();
	}
}
void NglGruLayer::ResetInnerState()
{
	// reset inner state .
	// 内部状態をリセット
	outputPrev_.Init(0.0f, outputPrev_.Num());
}

// GR特有のパラメータ行列用
unsigned int NglGruLayer::NumGateWeight(EWEIGHT_KIND kind) const
{
	return (EWEIGHT_KIND_MAX>kind) ? weightMatrixSizeArray_[kind] : 0;
}
unsigned int NglGruLayer::GetGateWeightHeadIndex(EWEIGHT_KIND kind) const
{
	return (EWEIGHT_KIND_MAX>kind) ? weightMatrixHeadArray_[kind] : 0;
}
unsigned int NglGruLayer::NumGateInput(EWEIGHT_KIND kind) const
{
	return (EWEIGHT_KIND_MAX>kind) ? gateInOutSize_[kind].numInput_ : 0;
}
unsigned int NglGruLayer::NumGateOutput(EWEIGHT_KIND kind) const
{
	return (EWEIGHT_KIND_MAX>kind) ? gateInOutSize_[kind].numOutput_ : 0;
}

// ----------------------------------------------------------------------------------------------------------------
// for Training Method.
//
// 初期値を正規分布で設定
// 再帰weightは対称行列になるようにしたほうが良いらしいけどとりあえず普通の乱数
void NglGruLayer::InitializeWeightWithNormalDistribution()
{
	for (int k = 0; k < EWEIGHT_KIND_MAX; ++k)
	{
		EWEIGHT_KIND kind = (EWEIGHT_KIND)k;
		unsigned int numGateInput = NumGateInput(kind);
		unsigned int numGateOutput = NumGateOutput(kind);
		unsigned int numGateWeight = NumGateWeight(kind);
		unsigned int weightHead = GetGateWeightHeadIndex(kind);

		float m = 0.0;
		float standardDeviation = FMath::Sqrt(2.0 / ( numGateInput * 2.0));

		for (unsigned int wi = weightHead; wi < weightHead+numGateWeight; ++wi)
		{
			//  "He" initialization
			float z = NglMathUtil::NormalRandom(m, standardDeviation);
			GetWeightPtr()[wi] = z;

#ifdef NGL_DEBUG_NAN_CHECK
			if (isnan(z) || isinf(z))
				UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglGruLayer::InitializeWeightWithNormalDistribution] NaN Weight."));
#endif
		}
	}
}

// BackPropagation. add learcning delta to update-matrix. practical update is UpdateWeight().
// 逆伝搬. 引数は出力側から伝搬してきた勾配ベクトル( レイヤの出力ニューロン数と一致 )
// 重み行列の更新値にデルタを足しこみ、前のレイヤへ伝搬する勾配を計算する.
// 実際の重み行列の更新はUpdateWeight()を実行することで処理される.
void NglGruLayer::BackPropagation(const float* backPropGradient, unsigned int size)
{
	if (!IsTrainMode())
		return;
	const unsigned int minSize = FMath::Min(size, NumOutput());

	const unsigned int inputDim = NumInput();
	const unsigned int outputDim = NumOutput();

	// どのゲートでもリカレント入力サイズは同じなのでENUMはどれでもよい
	const unsigned int recurrentDim = NumGateInput(UPDATE_RECURRENT);
	
	// clear backprop grad
	for (int i = 0; i < backPropagationGradient_.Num(); ++i)
		backPropagationGradient_[i] = 0.0f;

	/// ---------------------------------------------------------------------------
	// work buffer reset.
	for (unsigned int i = 0; i < recurrentDim; ++i)
		resetGateBackPropGradient_[i] = 0.0;

#if 0
	// recurrent backprop gradient
	// BPTTをちゃんとやる場合はこの勾配を未来に伝達する
	// 更新ゲートのリカレント伝搬勾配
	TArray<float> dEdR_updateGate;
	dEdR_updateGate.SetNumZeroed(NumGateInput(UPDATE_RECURRENT));
	// リセットゲートのリカレント伝搬勾配
	TArray<float> dEdR_resetGate;
	dEdR_resetGate.SetNumZeroed(NumGateInput(RESET_RECURRENT));
	// 候補ゲートのリカレント伝搬勾配
	TArray<float> dEdR_candidateGate;
	dEdR_candidateGate.SetNumZeroed(NumGateInput(CANDIDATE_RECURRENT));
#endif
	/// ---------------------------------------------------------------------------

	for (unsigned int o = 0; o < minSize; ++o)
	{
		// update gate
		{
			const unsigned int WHead = GetGateWeightHeadIndex(UPDATE_INPUT);
			const unsigned int UHead = GetGateWeightHeadIndex(UPDATE_RECURRENT);

			// derivate final unit respect to update-gate.
			// GURの前回出力と今回出力の線形補間の、更新ゲートに関する勾配
			const float dEdUpdateGate = backPropGradient[o] * (outputCandidateGate_[o].Value() - outputPrev_[o]);
			{
				const float delta = dEdUpdateGate * outputUpdateGate_[o].Differential();
				// input
				for (unsigned int i = 0; i < inputDim; ++i)
				{
					weightDeltaMatrix_[WHead + i + o * inputDim] = std::fmaf( delta, GetInput()[i], weightDeltaMatrix_[WHead + i + o * inputDim] );

					backPropagationGradient_[i] = std::fmaf( delta, GetWeightPtr()[WHead + i + o * inputDim], backPropagationGradient_[i] );
				}

				// recurrent
				for (unsigned int i = 0; i < recurrentDim; ++i)
				{
					weightDeltaMatrix_[UHead + i + o * recurrentDim] =
						std::fmaf( delta, outputPrev_[i], weightDeltaMatrix_[UHead + i + o * recurrentDim]);
#if 0
					// recurrent backprop gradient
					// BPTTをちゃんとやる場合はこの勾配を未来に伝達する
					//dEdR_updateGate[i] += delta * weightMatrix_[UHead + i + o * recurrentDim];
					dEdR_updateGate[i] = std::fmaf( delta, weightMatrix_[UHead + i + o * recurrentDim], dEdR_updateGate[i] );
#endif
				}
			}
		}

		// candidate gate
		{
			const unsigned int WHead = GetGateWeightHeadIndex(CANDIDATE_INPUT);
			const unsigned int UHead = GetGateWeightHeadIndex(CANDIDATE_RECURRENT);

			// derivate final unit respect to candidate-gate.
			// GURの前回出力と今回出力の線形補間の、候補ゲートに関する勾配
			const float dEdCandidateGate = backPropGradient[o] * outputUpdateGate_[o].Value();
			{
				const float delta = dEdCandidateGate * outputCandidateGate_[o].Differential();
				// input
				for (unsigned int i = 0; i < inputDim; ++i)
				{
					backPropagationGradient_[i] = std::fmaf( delta, GetWeightPtr()[WHead + i + o * inputDim], backPropagationGradient_[i] );

					weightDeltaMatrix_[WHead + i + o * inputDim] = std::fmaf( delta, GetInput()[i], weightDeltaMatrix_[WHead + i + o * inputDim] );
				}

				// recurrent
				for (unsigned int i = 0; i < recurrentDim; ++i)
				{
					weightDeltaMatrix_[UHead + i + o * recurrentDim] 
						= std::fmaf( delta, outputPrev_[i] * outputResetGate_[i].Value(), weightDeltaMatrix_[UHead + i + o * recurrentDim] );

					// for reset gate backprop.
					resetGateBackPropGradient_[i]
						= std::fmaf( delta, GetWeightPtr()[UHead + i + o * recurrentDim] * outputPrev_[i], resetGateBackPropGradient_[i] );
#if 0
					// recurrent backprop gradient
					// BPTTをちゃんとやる場合はこの勾配を未来に伝達する
					dEdR_candidateGate[i] 
						= std::fmaf( delta, weightMatrix_[UHead + i + o * recurrentDim] * outputResetGate_[i].Value(), dEdR_candidateGate[i] );
#endif
				}
			}
		}
	}

	// 最期にリセットゲート
	for( unsigned int o = 0; o < outputDim; ++o)
	{
		// reset gate
		{
			const unsigned int WHead = GetGateWeightHeadIndex(RESET_INPUT);
			const unsigned int UHead = GetGateWeightHeadIndex(RESET_RECURRENT);

			{
				const float delta = resetGateBackPropGradient_[o] * outputResetGate_[o].Differential();
				// input
				for (unsigned int i = 0; i < inputDim; ++i)
				{
					weightDeltaMatrix_[WHead + i + o * inputDim] = std::fmaf( delta, GetInput()[i], weightDeltaMatrix_[WHead + i + o * inputDim] );

					backPropagationGradient_[i] = std::fmaf( delta, GetWeightPtr()[WHead + i + o * inputDim], backPropagationGradient_[i] );
				}

				// recurrent
				for (unsigned int i = 0; i < recurrentDim; ++i)
				{
					weightDeltaMatrix_[UHead + i + o * recurrentDim] 
						= std::fmaf( delta, outputPrev_[i], weightDeltaMatrix_[UHead + i + o * recurrentDim] );
#if 0
					// recurrent backprop gradient
					// BPTTをちゃんとやる場合はこの勾配を未来に伝達する
					dEdR_resetGate[i] = std::fmaf( delta, weightMatrix_[UHead + i + o * recurrentDim], dEdR_resetGate[i] );
#endif
				}
			}
		}
	}
}

//--------------------------------------------------------

// ---------------------------------------------
	NglVoxelPosition::NglVoxelPosition()
	{
		NglVoxelPosition(1);
	}
	NglVoxelPosition::NglVoxelPosition(int numDimension)
	{
		numDimension_ = 0;
		resize(numDimension);
	}
	NglVoxelPosition::NglVoxelPosition(const int* pos, int numDimension)
	{
		numDimension_ = 0;
		resize(numDimension);
		setPos(pos, numDimension);
	}
	void NglVoxelPosition::setPos(int dimension, int posD)
	{
		if (0 <= dimension && numDimension() > dimension)
			pos_[dimension] = posD;
	}
	void NglVoxelPosition::setPos(const int* pos, int numDimension, bool fillTailByZero)
	{
		int n = FMath::Min(numDimension, this->numDimension());
		for (int i = 0; i < n; ++i)
			pos_[i] = pos[i];
		if (fillTailByZero)
		{
			for (int i = n; i < this->numDimension(); ++i)
				pos_[i] = 0;
		}
	}
	int NglVoxelPosition::getPos(int dimension) const
	{
		return (0 <= dimension && numDimension() > dimension) ? pos_[dimension] : 0;
	}
	// 
	void NglVoxelPosition::setAll(int value)
	{
		const int n = numDimension();
		for (int i = 0; i < n; ++i)
			setPos(i, value);
	}
	void NglVoxelPosition::resize(int numDimension)
	{
		int n = FMath::Max(numDimension, 1);// shrink
		if (numDimension_ < n)
		{
			TArray<int> buff = pos_;
			pos_.SetNum(n);
			for (int i = 0; i < numDimension_; ++i)
				pos_[i] = buff[i];
			// fill
			for (int i = numDimension_; i < n; ++i)
				pos_[i] = 0;
		}
		numDimension_ = n;
	}
	// 
	NglVoxelPosition& NglVoxelPosition::operator=(const NglVoxelPosition& obj)
	{
		pos_ = obj.pos_;// copy
		numDimension_ = obj.numDimension();
		return *this;
	}
	// Add
	NglVoxelPosition& NglVoxelPosition::operator+=(const NglVoxelPosition& obj)
	{
		int n = FMath::Max(numDimension(), obj.numDimension());
		resize(n);
		for (int i = 0; i < n; ++i)
			pos_[i] += obj.getPos(i);
		return *this;
	}
	// Subtract
	NglVoxelPosition& NglVoxelPosition::operator-=(const NglVoxelPosition& obj)
	{
		int n = FMath::Max(numDimension(), obj.numDimension());
		resize(n);
		for (int i = 0; i < n; ++i)
			pos_[i] -= obj.getPos(i);
		return *this;
	}
	// Mul
	NglVoxelPosition& NglVoxelPosition::operator*=(const NglVoxelPosition& obj)
	{
		int n = FMath::Max(numDimension(), obj.numDimension());
		resize(n);
		for (int i = 0; i < n; ++i)
			pos_[i] *= obj.getPos(i);
		return *this;
	}
	// Add
	NglVoxelPosition NglVoxelPosition::operator+(const NglVoxelPosition& obj) const
	{
		int n = FMath::Max(numDimension(), obj.numDimension());
		NglVoxelPosition out(n);
		for (int i = 0; i < n; ++i)
			out.pos_[i] = getPos(i) + obj.getPos(i);
		return out;
	}
	// Subtract
	NglVoxelPosition NglVoxelPosition::operator-(const NglVoxelPosition& obj) const
	{
		int n = FMath::Max(numDimension(), obj.numDimension());
		NglVoxelPosition out(n);
		for (int i = 0; i < n; ++i)
			out.pos_[i] = getPos(i) - obj.getPos(i);
		return out;
	}
	// Mul
	NglVoxelPosition NglVoxelPosition::operator*(const NglVoxelPosition& obj) const
	{
		int n = FMath::Max(numDimension(), obj.numDimension());
		NglVoxelPosition out(n);
		for (int i = 0; i < n; ++i)
			out.pos_[i] = getPos(i) * obj.getPos(i);
		return out;
	}

	bool NglVoxelPosition::lessEqualAllThan(const NglVoxelPosition& obj)
	{
		int n = FMath::Max(numDimension(), obj.numDimension());
		for (int i = 0; i < n; ++i)
			if (pos_[i] > obj.getPos(i))
				return false;
		return true;
	}
	bool NglVoxelPosition::lessAllThan(const NglVoxelPosition& obj)
	{
		int n = FMath::Max(numDimension(), obj.numDimension());
		for (int i = 0; i < n; ++i)
			if (pos_[i] >= obj.getPos(i))
				return false;
		return true;
	}


	// ---------------------------------------------
	NglShape::NglShape()
	{
		NglShape(1);
	}
	NglShape::NglShape(int numDimension)
	{
		int n = FMath::Max(numDimension, 1);
		shape_.Reserve(n);
		for (int i = 0; i < n; ++i)
			shape_.Add(1);
		recalcSize();
	}
	NglShape::NglShape(int* dimensionSizeArray, int dimensionSizeArraySize)
		: NglShape(dimensionSizeArraySize)
	{
		setShape(dimensionSizeArray, dimensionSizeArraySize);
	}
	void NglShape::setShape(int dimensionIndex, int dimensionSize)
	{
		if (0 > dimensionIndex || shape_.Num() <= dimensionIndex)
			return;
		shape_[dimensionIndex] = FMath::Max(dimensionSize, 1);
		recalcSize();
	}
	void NglShape::setShape(int* dimensionSizeArray, int dimensionSizeArraySize)
	{
		const int n = FMath::Min(dimensionSizeArraySize, shape_.Num());
		for (int i = 0; i < n; ++i)
			shape_[i] = FMath::Max(dimensionSizeArray[i], 1);
		recalcSize();
	}
	int NglShape::getDimensionSize(int index) const
	{
		if (0 > index || shape_.Num() <= index)
			return 1;
		return shape_[index];
	}
	// dim0Size * dim1Size * ... dimNSize.
	int NglShape::getVolumeSize() const
	{
		return size_;
	}
	int NglShape::numRow() const
	{
		return numRow_;
	}

	// traverse N-dimension position.
	// 多次元バッファ上の座標更新
	// 0~N-1次元のベクトルを メモリ配置順に巡回する
	bool NglShape::traverseShape(NglVoxelPosition& pos, int moveDimension) const
	{
		bool isCarry = true;
		// 指定された次元で移動をする
		for (int i = moveDimension; isCarry && i < pos.numDimension(); ++i)
		{
			pos.setPos(i, pos.getPos(i) + 1);
			isCarry = (getDimensionSize(i) <= pos.getPos(i));
			if (isCarry)
				pos.setPos(i, 0);
		}
		return !isCarry;
	};
	// calc element index from N-dimension position.
	// シェイプと座標から要素インデックスを計算
	int NglShape::calcIndex(const NglVoxelPosition& pos) const
	{
		unsigned int index = 0;
		unsigned int s = 1;
		for (int i = 0; i < pos.numDimension(); ++i)
		{
			index += s * pos.getPos(i);
			s *= getDimensionSize(i);
		}
		return index;
	};
	// check pos is in this shape.
	bool NglShape::isInner(const NglVoxelPosition& pos) const
	{
		int n = FMath::Max(numDimension(), pos.numDimension());
		for (int i = 0; i < n; ++i)
			if (0 > pos.getPos(i) || getDimensionSize(i) <= pos.getPos(i))
				return false;
		return true;
	}

	void NglShape::recalcSize()
	{
		size_ = 1;
		for (int i = 0; i < shape_.Num(); ++i)
			size_ *= shape_[i];
		numRow_ = size_ / shape_[0];
	}
// ---------------------------------------------

NglCnnLayer::NglCnnLayer()
{
}
NglCnnLayer::~NglCnnLayer()
{
}

// setup layer.
// kernelRadiusShape is filter radius. radius 1 -> 1x1 filter. radius 2 -> 3x3 filter. radius 3 -> 5x5 filter.
// 0-radius is treated internally as 1.
// カーネル半径を指定する.内部的に奇数サイズのカーネルとしたいためこのようにしている.
// カーネル半径1 -> 1x1, カーネル半径2 -> 3x3, カーネル半径3 -> 5x5 となる。
// カーネル半径0は1扱いとなる
bool NglCnnLayer::Initialize(unsigned int* inputShape, unsigned int inputShapeSize, unsigned int* outputShape, unsigned int outputShapeSize,
	unsigned int* kernelRadiusShape, unsigned int kernelRadiusShapeSize,
	unsigned int* strideShape, unsigned int strideShapeSize)
{
	if (!inputShape || 0 >= inputShapeSize)
		return false;
	if (!outputShape || 0 >= outputShapeSize)
		return false;
	if (!kernelRadiusShape || 0 >= kernelRadiusShapeSize)
		return false;
	if (!strideShape || 0 >= strideShapeSize)
		return false;

	// 次元数は入力と出力の内最大のものに合わせる（足りない部分はサイズ1にすることで帳尻合わせ）
	unsigned int numDimension = FMath::Max(inputShapeSize, outputShapeSize);

	// シェイプテスト
	{
		// 具体的なシェイプ情報を設定
		shape_[BK_INPUT] = NglShape(inputShapeSize);
		shape_[BK_INPUT].setShape( (int*)inputShape, (int)inputShapeSize );
		
		shape_[BK_OUTPUT] = NglShape(outputShapeSize);
		shape_[BK_OUTPUT].setShape((int*)outputShape, (int)outputShapeSize);

		shape_[BK_KERNEL] = NglShape(inputShapeSize);
		for (int i = 0; i < (int)kernelRadiusShapeSize; ++i)
		{
			shape_[BK_KERNEL].setShape(i, (int)kernelRadiusShape[i] * 2 - 1);
		}

		shape_[BK_INPUT_WITH_PADDING] = NglShape(inputShapeSize);
		shape_[BK_INPUT_WITH_PADDING].setShape((int*)inputShape, (int)inputShapeSize);

		stride_ = NglVoxelPosition(inputShapeSize);
		stride_.setPos((int*)strideShape, strideShapeSize);
		// stride greater than 1.
		for (int i = 0; i < stride_.numDimension(); ++i)
			stride_.setPos( i, FMath::Max(stride_.getPos(i), 1) );

		// init padding with zero.
		padding_[0] = NglVoxelPosition(inputShapeSize);
		padding_[1] = NglVoxelPosition(inputShapeSize);
	}

	// correct kernel shape size.
	// 入力シェイプに収まるようにカーネルシェイプを補正
	for ( unsigned int i = 0; i < numDimension; ++i)
	{
		if (shape_[BK_KERNEL].getDimensionSize(i) > shape_[BK_INPUT].getDimensionSize(i))
		{
			// kernel size most be Odd number.
			// カーネルが入力に収まるように修正. 奇数にする必要があるので注意
			shape_[BK_KERNEL].setShape( i, 
				shape_[BK_INPUT].getDimensionSize(i) - (1 - shape_[BK_INPUT].getDimensionSize(i) % 2)
				);
		}
	}
	// fix kernel size.
	// カーネルサイズが確定したらカーネル半径を保存
	shape_[BK_KERNEL_RADIUS] = NglShape(inputShapeSize);
	for (int i = 0; i < shape_[BK_KERNEL].numDimension(); ++i)
		shape_[BK_KERNEL_RADIUS].setShape(i, (shape_[BK_KERNEL].getDimensionSize(i)+1)/2 );

	// number of kernel.
	numKernel_ = 1;
	for (int i = shape_[BK_INPUT].numDimension(); i < shape_[BK_OUTPUT].numDimension(); ++i)
	{
		// input shape= [32,32], output shape=[16,16,3], number of kernel is 3.
		// 入力シェイプよりも大きい次元でのサイズの積をカーネル数とする. 例として入力[32,32]に対して出力[16,16,3] の場合はカーネル数3
		numKernel_ *= shape_[BK_OUTPUT].getDimensionSize(i);
	}

	// padding size. head and tail padding.
	// paddingサイズを計算
	for (int hi = 0; hi < 2; ++hi)
	{
		for (int i = 0; i < padding_[hi].numDimension(); ++i)
		{
			int tmp_osk = (shape_[BK_OUTPUT].getDimensionSize(i) - 1)
				* stride_.getPos(i) + shape_[BK_KERNEL].getDimensionSize(i);
			int tmp_i = shape_[BK_INPUT].getDimensionSize(i);
			// head padding <= tail padding.
			// 計算結果が負にならないようにしているだけ
			// +1 は出力サイズに帳尻があるようにパディングを水増ししている
			// 端数がある場合はバッファの先頭側のパディングを少なくするため hi(0,1)を足して2で割る
			int pad = (tmp_osk >= tmp_i) ? (tmp_osk - tmp_i + hi) / 2 : 0;

			padding_[hi].setPos(i, pad );
		}
	}
	// input shape with padding.
	for (int i = 0; i < (int)shape_[BK_INPUT_WITH_PADDING].numDimension(); ++i)
	{
		shape_[BK_INPUT_WITH_PADDING].setShape( i,
			shape_[BK_INPUT_WITH_PADDING].getDimensionSize(i) + padding_[0].getPos(i)+ padding_[1].getPos(i)
			);
	}

	// calc each kernel weight offset.
	kernelWeightOffsets_.Reserve(numKernel_);
	kernelWeightOffsets_.Add(0);
	for ( int i = 0; i < numKernel_-1; ++i )
	{
		kernelWeightOffsets_.Add(kernelWeightOffsets_[i] + shape_[BK_KERNEL].getVolumeSize());
	}

	// weight size is kernelSize * numKernel
	InitializeBase(shape_[BK_INPUT].getVolumeSize(),
		shape_[BK_OUTPUT].getVolumeSize(), shape_[BK_KERNEL].getVolumeSize() * numKernel_);

	// input work buffer.
	// パディングを含めたワーク用入力バッファを作成
	// ここに入力データをコピーしてカーネルをかける
	inputWork_.SetNumZeroed(shape_[BK_INPUT_WITH_PADDING].getVolumeSize());

	// default is Inference.
	SetToInferenceMode();

	return true;
}

// calc layer neuron activity with forward
// CNN is reshape input-buffer to own shape.
void NglCnnLayer::Forward(const float* input, unsigned int size)
{
	// copy to input buffer.
	{
		// 標準の入力バッファにコピー 外から入力情報を観る必要が無ければいらないかな？
		float* buffer = GetInput();
		unsigned int pi = 0;
		unsigned int targetIndex = 0;

		NglVoxelPosition inputPos(shape_[BK_INPUT].numDimension());
		for (inputPos.setAll(0); pi < size; ++pi)
		{
			targetIndex = shape_[BK_INPUT].calcIndex(inputPos);
			buffer[targetIndex] = input[pi];
			if (!shape_[BK_INPUT].traverseShape(inputPos, 0))
				break;
		}
		// zero fill to tail.
		for (int i = targetIndex + 1; i < shape_[BK_INPUT].numDimension(); ++i)
			buffer[i] = 0.0;
	}
	{
		// copy to input work buffer.
		// ワーク用入力バッファにコピー
		float* buffer = inputWork_.GetData();
		unsigned int pi = 0;
		unsigned int targetIndex = 0;

		NglVoxelPosition inputPos(shape_[BK_INPUT].numDimension());
		for (inputPos.setAll(0); pi < size; ++pi)
		{
			// offset by head-padding
			// インデックス計算はパディング込みシェイプで座標にパディングを加算する
			targetIndex = shape_[BK_INPUT_WITH_PADDING].calcIndex(inputPos + padding_[0]);
			buffer[targetIndex] = input[pi];
			if (!shape_[BK_INPUT].traverseShape(inputPos, 0))
				break;
		}
	}

	// filtering inputWork and kernel.
	//  パディング込みのinputWork_とKernelを畳み込みして output_に流す
	{
		float* inBuffer = inputWork_.GetData();
		float* outBuffer = GetOutput();
		const float* kernelHead = GetWeightPtr();

		const int kernelRowWidth = shape_[BK_KERNEL].getDimensionSize(0);

		NglVoxelPosition inRowHeadPos(shape_[BK_INPUT_WITH_PADDING].numDimension());
		NglVoxelPosition outRowHeadPos(shape_[BK_OUTPUT].numDimension());
		NglVoxelPosition kernelPos(shape_[BK_KERNEL].numDimension());
		for (;;)
		{
			// kernel index from output pos.
			int kernelIndex = 0;
			int layerVolume = 1;
			for (int i = shape_[BK_INPUT_WITH_PADDING].numDimension(); i < shape_[BK_OUTPUT].numDimension(); ++i)
			{
				kernelIndex += outRowHeadPos.getPos(i) * layerVolume;
				layerVolume *= shape_[BK_KERNEL].getDimensionSize(i);
			}
			const float* kernel = kernelHead + kernelIndex*shape_[BK_KERNEL].getVolumeSize();

			// loop for output row.
			int outputRowHeadIndex = shape_[BK_OUTPUT].calcIndex(outRowHeadPos);
			for (int ori = 0; ori < shape_[BK_OUTPUT].getDimensionSize(0); ++ori)
			{
				// filtering

				// input pos based on output pos.
				inRowHeadPos.setPos(outRowHeadPos.getPosPtr(), outRowHeadPos.numDimension());
				// move current row position.
				inRowHeadPos.setPos( 0, inRowHeadPos.getPos(0) + ori);
				// with stride. 
				inRowHeadPos *= stride_;
				
				float outTmp = 0.0f;
				for (int ki = 0; ki < shape_[BK_KERNEL].numRow(); ++ki)
				{
					int inputIndex = shape_[BK_INPUT_WITH_PADDING].calcIndex(inRowHeadPos);

					// filter on values at continuous memory.
					// 連続したメモリ上にある 0次元目データの計算を一気に実行
					for (int ri = 0; ri < kernelRowWidth; ++ri)
					{
						outTmp += inBuffer[inputIndex + ri] * kernel[ri + ki * kernelRowWidth];
					}

					// move. [a,b,c,d]->[a,b+1,c,d]. if dim-2 shape size over, Moving up.
					shape_[BK_INPUT_WITH_PADDING].traverseShape(inRowHeadPos, 1);
				}
				// write to output-buffer.
				outBuffer[outputRowHeadIndex + ori] = outTmp;
			}

			// move. [a,b,c,d]->[a,b+1,c,d]. if dim-2 shape size over, Moving up.
			if (!shape_[BK_OUTPUT].traverseShape(outRowHeadPos, 1))
				break;
		}
	}

#ifdef NGL_DEBUG_NAN_CHECK
	// check output NaN.
	for (unsigned int i = 0; i < NumOutput(); ++i)
	{
		const float o = GetOutput()[i];
		if (isnan(o) || isinf(o))
			UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglCnnLayer::Forward] NaN Output."));
	}
#endif
}

// Call at change mode. Train-Mode is True, Inference-Mode is False.
// ネットワークの学習モードと推論モードを切り替え. デフォルトはメモリ使用量の少ない推論モード
// change network mode with Train or Inference. default is Inference for reasons of low memory usage.
void NglCnnLayer::OnChangeTrainMode(bool toTrainMode)
{
	NglNeuralNetworkLayerBase::OnChangeTrainMode(toTrainMode);
	if (toTrainMode)
	{
	}
	else
	{
	}
}

// ----------------------------------------------------------------------------------------------------------------
// for Training Method.
//
// 初期値を正規分布で設定
void NglCnnLayer::InitializeWeightWithNormalDistribution()
{
	float m = 0.0;
	float standardDeviation = FMath::Sqrt(2.0 / shape_[BK_KERNEL].getVolumeSize());

	// initialize weight by He's method.
	// フィルタ毎にHeで初期化
	for (int k = 0; k < numKernel_; ++k)
	{
		for (int i = 0; i < shape_[BK_KERNEL].getVolumeSize(); ++i)
		{
			float z = NglMathUtil::NormalRandom(m, standardDeviation);

			GetWeightPtr()[kernelWeightOffsets_[k] + i] = z;
#ifdef NGL_DEBUG_NAN_CHECK
			if (isnan(z) || isinf(z))
				UE_LOG(LogTemp, Log, TEXT("		[ERROR][NglCnnLayer::InitializeWeightWithNormalDistribution] NaN Weight."));
#endif
		}
	}
}

// BackPropagation. add learcning delta to update-matrix. practical update is UpdateWeight().
// 逆伝搬. 引数は出力側から伝搬してきた勾配ベクトル( レイヤの出力ニューロン数と一致 )
// 重み行列の更新値にデルタを足しこみ、前のレイヤへ伝搬する勾配を計算する.
// 実際の重み行列の更新はUpdateWeight()を実行することで処理される.
void NglCnnLayer::BackPropagation(const float* backPropGradient, unsigned int size)
{
	//  パディング込みのinputWork_とKernelを畳み込みして output_に流す
	float* inBuffer = GetInput();
	float* outBuffer = GetOutput();
	const float* kernelHead = GetWeightPtr();
	float* weightDeltaHead = weightDeltaMatrix_.GetData();

	const int kernelRowWidth = shape_[BK_KERNEL].getDimensionSize(0);

	NglVoxelPosition inRowHeadPos(shape_[BK_INPUT_WITH_PADDING].numDimension());
	NglVoxelPosition inPosNoPadding(shape_[BK_INPUT_WITH_PADDING].numDimension());
	NglVoxelPosition outRowHeadPos(shape_[BK_OUTPUT].numDimension());
	NglVoxelPosition kernelPos(shape_[BK_KERNEL].numDimension());

	// clear backprop grad
	for (int i = 0; i < backPropagationGradient_.Num(); ++i)
		backPropagationGradient_[i] = 0.0f;

	for (;;)
	{
		// kernel index from output pos.
		int kernelIndex = 0;
		int layerVolume = 1;
		for (int i = shape_[BK_INPUT_WITH_PADDING].numDimension(); i < shape_[BK_OUTPUT].numDimension(); ++i)
		{
			kernelIndex += outRowHeadPos.getPos(i) * layerVolume;
			layerVolume *= shape_[BK_KERNEL].getDimensionSize(i);
		}
		const float* kernel = kernelHead + kernelIndex * shape_[BK_KERNEL].getVolumeSize();

		float* weightDelta = weightDeltaHead + kernelIndex * shape_[BK_KERNEL].getVolumeSize();

		// loop for output row.
		int outputRowHeadIndex = shape_[BK_OUTPUT].calcIndex(outRowHeadPos);
		if (size > static_cast<unsigned int>(outputRowHeadIndex))
		{
			for (int ori = 0; ori < shape_[BK_OUTPUT].getDimensionSize(0); ++ori)
			{
				// input pos based on output pos.
				inRowHeadPos.setPos(outRowHeadPos.getPosPtr(), inRowHeadPos.numDimension());
				// move current row position.
				inRowHeadPos.setPos(0, inRowHeadPos.getPos(0) + ori);
				// with stride. 
				inRowHeadPos *= stride_;


				float outTmp = 0.0f;
				for (int ki = 0; ki < shape_[BK_KERNEL].numRow(); ++ki)
				{
					// filter on values at continuous memory.
					// 連続したメモリ上にある 0次元目データの計算を一気に実行
					for (int ri = 0; ri < kernelRowWidth; ++ri)
					{
						inPosNoPadding.setPos(inRowHeadPos.getPosPtr(), inRowHeadPos.numDimension());// base on left
						inPosNoPadding.setPos(0, inPosNoPadding.getPos(0) + ri);// move row offset
						inPosNoPadding -= padding_[0];// subtract head-padding
						if (shape_[BK_INPUT].isInner(inPosNoPadding))
						{
							int inputIndex = shape_[BK_INPUT].calcIndex(inPosNoPadding);

							// add backprop grad.
							backPropagationGradient_[inputIndex] =
								std::fmaf(backPropGradient[outputRowHeadIndex + ori],
									kernel[ri + ki * kernelRowWidth],
									backPropagationGradient_[inputIndex]);

							// add weight delta.
							weightDelta[ri + ki * kernelRowWidth] =
								std::fmaf(backPropGradient[outputRowHeadIndex + ori],
									inBuffer[inputIndex],
									weightDelta[ri + ki * kernelRowWidth]);
						}
					}
					// move. [a,b,c,d]->[a,b+1,c,d]. if dim-2 shape size over, Moving up.
					shape_[BK_INPUT_WITH_PADDING].traverseShape(inRowHeadPos, 1);
				}
			}
		}

		// move. [a,b,c,d]->[a,b+1,c,d]. if dim-2 shape size over, Moving up.
		if (!shape_[BK_OUTPUT].traverseShape(outRowHeadPos, 1))
			break;
	}
}


//--------------------------------------------------------




NglSimpleLayerStackNN::NglSimpleLayerStackNN()
{
	Cleanup();
}
NglSimpleLayerStackNN::~NglSimpleLayerStackNN()
{
	// delete layers
	layers_.Empty();
}
bool NglSimpleLayerStackNN::IsValidLayerNeuron(unsigned int layer, unsigned int neuron) const
{
	return (NumLayer() > layer && NumLayerNeuron(layer) > neuron);
}

void NglSimpleLayerStackNN::Cleanup()
{
	// delete layers
	layers_.Empty();

	SetLearningRate(0.001f);
	SetLearningMomentum(0.95f);
	SetL2RegularizationRate(0.0f);
	SetMiniBatchSize(1);
	miniBatchAddCounter_ = 0;

	SetGradientCheckingEnable(false);
	isTrainMode_ = false;


	// default cost function is SquareError
	// 基底では二乗誤差をコスト関数とする
	SetCostFunction(TSharedPtr<NglCostFuncBase>(new NglCostFuncSquareError()));
}
bool NglSimpleLayerStackNN::AddLayer(const TSharedPtr<NglNeuralNetworkLayerBase>& newLayer)
{
	if (!newLayer.IsValid())
		return false;

	// change layer-mode to network mode
	if (IsTrainMode())
	{
		newLayer->SetToTrainMode();
	}
	else
	{
		newLayer->SetToInferenceMode();
	}

	layers_.Add(newLayer);

	return true;
}
// Set Cost Function for learning.
// コスト関数をセット
void NglSimpleLayerStackNN::SetCostFunction(const TSharedPtr<NglCostFuncBase>& costFunc)
{
	costFunc_ = costFunc;
}
void NglSimpleLayerStackNN::SetLearningRate(float rate)
{
	learningRate_ = 0.0 <= rate? rate : 0.0;
}
void NglSimpleLayerStackNN::SetLearningMomentum(float m)
{
	learningMomentum_ = 0.0 <= m ? m : 0.0;
}
void NglSimpleLayerStackNN::SetL2RegularizationRate(float rate) 
{ 
	l2RegularizationRate = 0.0 <= rate ? rate : 0.0;
}

unsigned int NglSimpleLayerStackNN::NumLayer() const
{
	return layers_.Num();
}
unsigned int NglSimpleLayerStackNN::NumLayerNeuron(unsigned int layer) const
{
	if (NumLayer() <= layer)
		return 0;
	return layers_[layer]->NumOutput();
}

unsigned int NglSimpleLayerStackNN::NumInputLayerNeuron() const
{
	return NumLayerNeuron(0);
}
unsigned int NglSimpleLayerStackNN::NumOutputLayerNeuron() const
{
	// 符号無し整数の減算注意
	if (0 >= NumLayer())
		return 0;
	return NumLayerNeuron(NumLayer() - 1);
}
const float* NglSimpleLayerStackNN::GetActivities(unsigned int layer) const
{
	if (NumLayer() <= layer)
		return nullptr;
	return layers_[layer]->GetOutput();
}
float* NglSimpleLayerStackNN::GetActivities(unsigned int layer)
{
	if (NumLayer() <= layer)
		return nullptr;
	return layers_[layer]->GetOutput();
}

const float* NglSimpleLayerStackNN::GetOutputActivities() const
{
	return GetActivities(NumLayer() - 1);
}
float* NglSimpleLayerStackNN::GetOutputActivities()
{
	return GetActivities(NumLayer() - 1);
}


float NglSimpleLayerStackNN::GetActivity(unsigned int layer, unsigned int neuron) const
{
	if (!IsValidLayerNeuron(layer, neuron))
		return 0.0f;
	const float* ptr = GetActivities(layer);
	if (nullptr == ptr)
		return 0.0f;
	return ptr[neuron];
}
float NglSimpleLayerStackNN::GetOutputActivity(unsigned int neuron) const
{
	return GetActivity(NumLayer() - 1, neuron);
}

void NglSimpleLayerStackNN::Forward(const TArray<float>& input)
{
	const float* inputData = input.GetData();
	unsigned int inputDataSize = input.Num();
	for (unsigned int i = 0; i < NumLayer(); ++i)
	{
		// forward propagation
		layers_[i]->Forward(inputData, inputDataSize);

		// setup next layer input
		inputData = layers_[i]->GetOutput();
		inputDataSize = layers_[i]->NumOutput();
	}
}

// change network mode with Train or Inference. default is Inference for reasons of low memory usage.
// ネットワークの学習モードと推論モードを切り替え. デフォルトはメモリ使用量の少ない推論モード
void NglSimpleLayerStackNN::SetToTrainMode()
{
	isTrainMode_ = true;
	for (unsigned int i = 0; i < NumLayer(); ++i)
	{
		layers_[i]->SetToTrainMode();
	}
}
void NglSimpleLayerStackNN::SetToInferenceMode()
{
	isTrainMode_ = false;
	for (unsigned int i = 0; i < NumLayer(); ++i)
	{
		layers_[i]->SetToInferenceMode();
	}
}
void NglSimpleLayerStackNN::SetGradientCheckingEnable(bool v)
{
	gradientCheckingEnable_ = v;
	if (!gradientCheckingEnable_)
	{
		// remove gradient checnking buffers.
		weightLayerOffset_.Empty();
		weightAnalyticDifference_.Empty();
		weightNumericalDifference_.Empty();
	}
}

void NglSimpleLayerStackNN::ResetInnerState()
{
	for (unsigned int i = 0; i < NumLayer(); ++i)
	{
		layers_[i]->ResetInnerState();
	}
}
void NglSimpleLayerStackNN::SetInnerStateUpdatable(bool flag)
{
	for (unsigned int i = 0; i < NumLayer(); ++i)
	{
		layers_[i]->SetInnerStateUpdatable(flag);
	}
}

void NglSimpleLayerStackNN::Train(const TArray<float>& input, const TArray<float>& teacher)
{
	if (!gradientCheckingEnable_)
		_Train(input, teacher);
	else
		_TrainWithGradientChecking(input, teacher);
}
// train
void NglSimpleLayerStackNN::_Train(const TArray<float>& input, const TArray<float>& teacher, TArray<float>* outAnalyticDifference)
{
	if (0 >= NumLayer())
		return;

	// invalid cost function.
	// コスト関数が設定されていない
	if (!costFunc_.IsValid())
	{
		UE_LOG(LogTemp, Log, TEXT("[ERROR][NglSimpleLayerStackNN::Train] Invalid Cost Function."));
		return;
	}

	// disable inner state update. ( for RNN )
	SetInnerStateUpdatable(false);
	// First Forward.
	Forward(input);

	// get output
	const float* layerOutput = GetOutputActivities();
	const unsigned int numOutput = NumOutputLayerNeuron();

	TArray<NglDualNumber> argDual;
	TArray<float> costGrad;
	argDual.SetNumUninitialized(numOutput);
	costGrad.SetNumZeroed(numOutput);
	for (unsigned int i = 0; i < numOutput; ++i)
	{
		argDual[i] = (NglDualNumber(layerOutput[i]));
	}

	// save last Forward Cost Value 
	lastTrainCostValue_ = (*costFunc_)(argDual, teacher).Value();

	// L2-Regularization Cost
	for (unsigned int i = 0; i < NumLayer(); ++i)
	{
		lastTrainCostValue_ += layers_[i]->CalcL2RegularizationCost(l2RegularizationRate);
	}

	// main training process
	if (IsTrainMode())
	{
		// output gradient.
		for (unsigned int i = 0; i < numOutput; ++i)
		{
			// set derivative target.
			argDual[i].DerivativeRespect();
			// grad
			costGrad[i] = (*costFunc_)(argDual, teacher).Differential();
			// reset derivative target.
			argDual[i].DerivativeRespect(false);
		}

		// back propagation output-layer to input-layer
		const unsigned int numLayer = NumLayer();
		for (unsigned int i = 0; i < numLayer; ++i)
		{
			int l = int(numLayer - i) - 1;

			int backpropGradientSize = (0 == i) ? costGrad.Num() : layers_[l + 1]->NumBackPropagationGradient();
			const float* backpropGradient = (0 == i) ? costGrad.GetData() : layers_[l + 1]->GetBackPropagationGradient();

			layers_[l]->BackPropagation(backpropGradient, backpropGradientSize);
		}

		// save backProp Gradient for gradient chacking.
		if (outAnalyticDifference)
		{
			for (unsigned int i = 0; i < numLayer; ++i)
			{
				for (unsigned int lwi = 0; lwi < layers_[i]->NumWeight(); ++lwi)
					outAnalyticDifference->Add(layers_[i]->GetWeightGradientAtIndex(lwi));
			}
		}

		// increment buffering counter.
		++miniBatchAddCounter_;

		// Apply when buffering counter exceeds a bufferingCount.
		if (GetMiniBatchSize() <= miniBatchAddCounter_)
		{
			// update weight with delta
			for (unsigned int i = 0; i < numLayer; ++i)
			{
				layers_[i]->UpdateWeight(miniBatchAddCounter_, learningRate_, learningMomentum_, l2RegularizationRate);
			}
			// reset buffering counter.
			miniBatchAddCounter_ = 0;
		}
	}

	// enable inner state update
	SetInnerStateUpdatable(true);
	// Forward with inner state update.
	Forward(input);

}

// gradient checking	
void NglSimpleLayerStackNN::_TrainWithGradientChecking(const TArray<float>& input, const TArray<float>& teacher)
{
	if (!IsTrainMode())
	{
		UE_LOG(LogTemp, Log, TEXT("[ERROR][NglSimpleLayerStackNN::TrainWithGradientChecking] Mode is not Train."));
		return;
	}
	if (0 >= NumLayer())
		return;
	// cost function Invalid
	// コスト関数が設定されていない
	if (!costFunc_.IsValid())
	{
		UE_LOG(LogTemp, Log, TEXT("[ERROR][NglSimpleLayerStackNN::TrainWithGradientChecking] Invalid Cost Function."));
		return;
	}

	// disable inner state update.
	SetInnerStateUpdatable(false);
	// first forward
	Forward(input);

	TArray<NglDualNumber> argDual;
	NglDualNumber baseCost;
	NglDualNumber epsilonCost;
	argDual.SetNumUninitialized(NumOutputLayerNeuron());
	const float* layerOutput = GetOutputActivities();
	for (unsigned int i = 0; i < NumOutputLayerNeuron(); ++i)
	{
		argDual[i] = (NglDualNumber(layerOutput[i]));
	}
	// const value
	baseCost = (*costFunc_)(argDual, teacher);


	// setup gradient checking buffer
	{
		weightAnalyticDifference_.Reset();
		weightLayerOffset_.Reset();

		unsigned int numAllWeight = 0;
		for (unsigned int i = 0; i < NumLayer(); ++i)
		{
			weightLayerOffset_.Add(numAllWeight);
			numAllWeight += layers_[i]->NumWeight();
		}
		weightNumericalDifference_.SetNum(numAllWeight);
	}

	// gradient checking
	for (unsigned int i = 0; i < NumLayer(); ++i)
	{
		for (unsigned int j = 0; j < layers_[i]->NumWeight(); ++j)
		{
			// 
			float w = layers_[i]->GetWeightAtIndex( j );
			// change one weight.
			layers_[i]->SetWeightAtIndex( j, w + GRADIENT_CHECKING_EPSILON );
			// 
			Forward(input);
			// restore weight.
			layers_[i]->SetWeightAtIndex(j, w );

			for (unsigned int o = 0; o < NumOutputLayerNeuron(); ++o)
				argDual[o] = (NglDualNumber(layerOutput[o]));

			// difference of base-cost and one-weight-changed-cost. it it numerical gradient.
			NglDualNumber diff = (*costFunc_)(argDual, teacher) - baseCost;
			// save numerical difference.
			weightNumericalDifference_[weightLayerOffset_[i] + j] = diff.Value() / GRADIENT_CHECKING_EPSILON;

		}
	}

	// 
	_Train( input, teacher, &weightAnalyticDifference_);

	// compare numerical gradient and backprop gradient.
	for (unsigned int i = 0; i < NumLayer(); ++i)
	{
		for (unsigned int j = 0; j < layers_[i]->NumWeight(); ++j)
		{
			// backpropagation gradient.
			float bpGrad = weightAnalyticDifference_[weightLayerOffset_[i] + j];
			// numerical differentiation
			float ndGrad = weightNumericalDifference_[weightLayerOffset_[i] + j];

			UE_LOG(LogTemp, Log, TEXT("[Gradient Checking][layer=%d][weight=%d] bp=%f,  nd=%f."), i, j, bpGrad, ndGrad);
			if (0.0f > (bpGrad*ndGrad))
			{
				UE_LOG(LogTemp, Log, TEXT("		[ERROR][Gradient Checking] Gradient Direction Is Inverse."));
			}
			else
			{
				float gradDiff = ndGrad - bpGrad;
				if (0.0f != gradDiff)
				{
					float gradDiffAbs = fabsf(gradDiff);
					if ( 0.01 < gradDiffAbs)
					{
						UE_LOG(LogTemp, Log, TEXT("		[ERROR][Gradient Checking] Gradient Difference is too Large."));
					}
				}
			}
		}
	}

	// enable inner state update
	SetInnerStateUpdatable(true);
	// Forward with inner state update.
	Forward(input);
}
//--------------------------------------------------------


NglNeuralNetworkCore::NglNeuralNetworkCore()
{
}

NglNeuralNetworkCore::~NglNeuralNetworkCore()
{
}
