﻿/*
	Copyright (c) 2018 Taro Horikawa

	twitter@nagakagachi
*/

#include "NglSimpleLayerStackNN.h"

//#include "FileHelper.h"
#include "Misc/FileHelper.h"

#include "Json.h"

//#include "Paths.h"
#include "Misc/Paths.h"


// file path fix
static FString generateJsonPath(const FString& filePath, const FString& baseDirPath)
{
	if (0 >= filePath.Len())
		return FString("");
	FString dirPath, fileName, extension;
	FPaths::Split(filePath, dirPath, fileName, extension);
	if (0 >= fileName.Len())
		return FString("");
	if (0 >= dirPath.Len())
		dirPath = baseDirPath;// base of relative path is SaveDir.
	else
		dirPath += TEXT("/");// add /
	if (0 >= extension.Len())
		extension = TEXT("json");
	// fixed File Path
	return dirPath + fileName + TEXT(".") + extension;
}


UNglSimpleLayerStackNN::UNglSimpleLayerStackNN()
{
}

void UNglSimpleLayerStackNN::BeginDestroy()
{
	Super::BeginDestroy();
}

void UNglSimpleLayerStackNN::AddLayer(UNglNeuralNetworkLayerBase* layer)
{
	if (nullptr == layer)
		return;
	if (nullptr == layer->GetLayer().Get())
	{
		UE_LOG(LogTemp, Log, TEXT("[ERROR][UNglSimpleLayerStackNN][AddLayer] Layer is NULL."));
		return;
	}
	// add layer object holder
	layers_.Add(layer);
	// add layer to nn core
	nn_.AddLayer(layer->GetLayer());
}

void UNglSimpleLayerStackNN::Train(const TArray<float>& input, const TArray<float>& teach)
{
#if 1
	nn_.Train(input, teach);
#else
	nn_.TrainWithGradientChecking(input, teach);
#endif
}

void UNglSimpleLayerStackNN::Forward(const TArray<float>& input)
{
	nn_.Forward(input);
}

bool UNglSimpleLayerStackNN::SaveJson(const FString& inputFilePath)
{
	if (0 >= inputFilePath.Len())
		return false;
	const FString filePath = generateJsonPath(inputFilePath, FPaths::ProjectSavedDir());

	TSharedPtr<FJsonObject> JsonObjectRoot(new FJsonObject);

	// ----------------------------------------------------------------------------------------------------
	// write Layer ClassName
	JsonObjectRoot->SetStringField("ClassName", StaticClass()->GetName());
	{
		// write each neuralNetwork layer parameters.
		TArray< TSharedPtr<FJsonValue> > ObjArray;
		for (int li = 0; li < layers_.Num(); ++li)
		{
			auto newChild = TSharedPtr<FJsonValueObject>(new FJsonValueObject(TSharedPtr<FJsonObject>(new FJsonObject())));
			{
				TSharedPtr<FJsonObject> layerJsonObj = newChild->AsObject();
				{
					layers_[li]->SaveJsonEntry(layerJsonObj.Get());
				}
			}
			ObjArray.Add(newChild);
		}
		JsonObjectRoot->SetArrayField("LayerArray", ObjArray);
	}
	// ----------------------------------------------------------------------------------------------------

	FString writeData = "";
	TSharedRef< TJsonWriter<> > Writer = TJsonWriterFactory<>::Create(&writeData);
	// write JsonData to JsonWriter.
	FJsonSerializer::Serialize(JsonObjectRoot.ToSharedRef(), Writer);
	// write Json to File.
	FFileHelper::SaveStringToFile(writeData, filePath.GetCharArray().GetData());

	return false;
}

bool UNglSimpleLayerStackNN::LoadJson(const FString& inputFilePath)
{
	// reset
	Cleanup();

	if (0 >= inputFilePath.Len())
		return false;
	const FString filePath = generateJsonPath(inputFilePath, FPaths::ProjectSavedDir());

	TSharedPtr<FJsonObject> JsonObjectRoot(new FJsonObject);

	FString readData = "";
	if (!FFileHelper::LoadFileToString(readData, filePath.GetCharArray().GetData()))
		return false;
	// read File
	TSharedRef< TJsonReader<> > Reader = TJsonReaderFactory<>::Create(readData);
	if (!FJsonSerializer::Deserialize(Reader, JsonObjectRoot))
		return false;

	// ----------------------------------------------------------------------------------------------------
	// 
	// Check Class Name
	FString className;
	if (!JsonObjectRoot->TryGetStringField("ClassName", className) || StaticClass()->GetName() != className)
	{
		// class name not found.
		// クラス名が用意されたレイヤクラスに存在しない.
		UE_LOG(LogTemp, Log, TEXT("[ERROR][UNglSimpleLayerStackNN][LoadJson] Json Class Name Field is Not Found or Not Match."));
	}

	// load and construct neural network layer class.
	const TArray< TSharedPtr<FJsonValue> > *layerArrayJson;
	if (JsonObjectRoot->TryGetArrayField("LayerArray", layerArrayJson))
	{
		for (const auto& layerJson : *layerArrayJson)
		{
			const TSharedPtr<FJsonObject> *jo;
			if (layerJson->TryGetObject(jo))
			{
				UNglNeuralNetworkLayerBase* newLayer =
					NglNeuralNetworkClassCatalog::GetInstance().CallLayerCreateFunc(jo->Get()->GetStringField("LayerType"));
				if (newLayer)
				{
					// setup by json
					if (!newLayer->LoadJsonEntry(jo->Get()))
					{
						// Failed
						delete newLayer;
					}
					else
					{
						// success
						AddLayer(newLayer);
					}
				}
			}
		}
	}
	// ----------------------------------------------------------------------------------------------------

	return true;
}