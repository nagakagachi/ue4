﻿/*
	Copyright (c) 2018 Taro Horikawa

	twitter@nagakagachi
*/

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include <functional>
#include "NglNeuralNetworkCore.h"

#include "NglNeuralNetworkComponents.generated.h"

/*
Neural Network UClass Defines.
*/


class FJsonObject;

struct NglNeuralNetworkBaseInitializer
{
	NglNeuralNetworkBaseInitializer()
	{
		numInput_ = 0;
		numOutput_ = 0;
	}
	int numInput_;
	int numOutput_;
};


//----------------------------------------------------------------------------------

// Layer Base
// レイヤ基底
UCLASS(NotBlueprintable)
class NGLNN_API UNglNeuralNetworkLayerBase : public UObject
{
	GENERATED_BODY()
public:
	// Sets default values for this actor's properties
	UNglNeuralNetworkLayerBase()
	{
	}

	TSharedPtr<NglNeuralNetworkLayerBase> GetLayer()
	{
		return layerBase_;
	}

	// get input side neuron count.
	UFUNCTION(BlueprintPure)
	int NumInput()
	{
		return static_cast<int>(layerBase_->NumInput());
	}

	// get output side neuron count.
	UFUNCTION(BlueprintPure)
	int NumOutput()
	{
		return static_cast<int>(layerBase_->NumOutput());
	}

	// get weight parameter count.
	UFUNCTION(BlueprintPure)
	int NumWeight()
	{
		return static_cast<int>(layerBase_->NumWeight());
	}

	// get weight parameter array.
	UFUNCTION(BlueprintPure)
	const TArray<float>& GetWeight()
	{
		return layerBase_->GetWeight();
	}
	
	// set weight parameter array.
	UFUNCTION(BlueprintCallable)
	void SetWeight( const TArray<float>& weight, bool isForce )
	{
		layerBase_->SetWeight( weight.GetData(), weight.Num(), isForce );
	}

	// Entry Point of Save to Json.
	bool SaveJsonEntry(FJsonObject* jsonObject) const;
	// Entry Point of Load from Json..
	bool LoadJsonEntry(const FJsonObject* jsonObject);


	// Save to Json. do Implement on Inherit Class.
	virtual bool SaveJson(FJsonObject* jsonObject) const { return false; };
	// Load from Json. do Implement on Inherit Class.
	virtual bool LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer) { return false; }

protected:
	// set layer object on inherit class.
	void setLayerCore(TSharedPtr<NglNeuralNetworkLayerBase> layer)
	{
		layerBase_ = layer;
	}
	TSharedPtr< NglNeuralNetworkLayerBase > layerBase_;
};

// define Create Layer Class Function Macro.
#define NGLNN_LAYER_CLASS_OBJECT_CREATE_FUNC_DEF( class_name )\
public:\
static UNglNeuralNetworkLayerBase* Create()\
{\
	return NewObject<class_name>();\
}



//----------------------------------------------------------------------------------
// Activation Layer
//----------------------------------------------------------------------------------

// ReLU Layer. (Activation Layer)
//	out = max(input + bias).
UCLASS(BlueprintType)
class NGLNN_API UNglReluLayer : public UNglNeuralNetworkLayerBase
{
	GENERATED_BODY()
public:
	NGLNN_LAYER_CLASS_OBJECT_CREATE_FUNC_DEF(UNglReluLayer);

	// Sets default values for this actor's properties
	UNglReluLayer()
	{
		layer_ = TSharedPtr< NglReluLayer >(new NglReluLayer());
		setLayerCore(layer_);
	}
	// initialize layer
	UFUNCTION(BlueprintCallable)
		UNglReluLayer* Initialize( int numInput )
	{
		layer_->Initialize(numInput);
		return this;
	}
	// create and initialize layer
	UFUNCTION(BlueprintCallable, DisplayName="Create NglReluLayer")
	static	UNglReluLayer* Create(int numInput)
	{
		return NewObject<UNglReluLayer>()->Initialize(numInput);
	}

	bool LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer);

private:
	TSharedPtr< NglReluLayer > layer_;
};
// Sigmoid Layer. (Activation Layer)
//	out = sigmoid(input + bias).
UCLASS(BlueprintType)
class NGLNN_API UNglSigmoidLayer : public UNglNeuralNetworkLayerBase
{
	GENERATED_BODY()
public:
	NGLNN_LAYER_CLASS_OBJECT_CREATE_FUNC_DEF(UNglSigmoidLayer);

	// Sets default values for this actor's properties
	UNglSigmoidLayer()
	{
		layer_ = TSharedPtr< NglSigmoidLayer >(new NglSigmoidLayer());
		setLayerCore(layer_);
	}
	// initialize layer
	UFUNCTION(BlueprintCallable)
		UNglSigmoidLayer* Initialize( int numInput )
	{
		layer_->Initialize(numInput);
		return this;
	}
	// create and initialize layer
	UFUNCTION(BlueprintCallable, DisplayName = "Create NglSigmoidLayer")
		static	UNglSigmoidLayer* Create(int numInput)
	{
		return NewObject<UNglSigmoidLayer>()->Initialize(numInput);
	}

	bool LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer);

private:
	TSharedPtr< NglSigmoidLayer > layer_;
};
// Hyperbolic-Tangent Layer. (Activation Layer)
//	out = tanh(input + bias).
UCLASS(BlueprintType)
class NGLNN_API UNglTanhLayer : public UNglNeuralNetworkLayerBase
{
	GENERATED_BODY()
public:
	NGLNN_LAYER_CLASS_OBJECT_CREATE_FUNC_DEF(UNglTanhLayer);

	// Sets default values for this actor's properties
	UNglTanhLayer()
	{
		layer_ = TSharedPtr< NglTanhLayer >(new NglTanhLayer());
		setLayerCore(layer_);
	}
	// initialize layer
	UFUNCTION(BlueprintCallable)
		UNglTanhLayer* Initialize(int numInput)
	{
		layer_->Initialize(numInput);
		return this;
	}
	// create and initialize layer
	UFUNCTION(BlueprintCallable, DisplayName = "Create NglTanhLayer")
		static	UNglTanhLayer* Create(int numInput)
	{
		return NewObject<UNglTanhLayer>()->Initialize(numInput);
	}

	bool LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer);

private:
	TSharedPtr< NglTanhLayer > layer_;
};
// Softplus Layer. (Activation Layer)
//	out = log( exp(input + bias) + 1.0 ).
UCLASS(BlueprintType)
class NGLNN_API UNglSoftplusLayer : public UNglNeuralNetworkLayerBase
{
	GENERATED_BODY()
public:
	NGLNN_LAYER_CLASS_OBJECT_CREATE_FUNC_DEF(UNglSoftplusLayer);

	// Sets default values for this actor's properties
	UNglSoftplusLayer()
	{
		layer_ = TSharedPtr< NglSoftplusLayer >(new NglSoftplusLayer());
		setLayerCore(layer_);
	}
	// initialize layer
	UFUNCTION(BlueprintCallable)
		UNglSoftplusLayer* Initialize(int numInput)
	{
		layer_->Initialize(numInput);
		return this;
	}
	// create and initialize layer
	UFUNCTION(BlueprintCallable, DisplayName = "Create NglSoftplusLayer")
		static	UNglSoftplusLayer* Create(int numInput)
	{
		return NewObject<UNglSoftplusLayer>()->Initialize(numInput);
	}

	bool LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer);

private:
	TSharedPtr< NglSoftplusLayer > layer_;
};
//----------------------------------------------------------------------------------

// Softmax Layer.
//	output is probability.
//	ソフトマックスレイヤ. 出力が確率値となるようなレイヤ.
UCLASS(BlueprintType)
class NGLNN_API UNglSoftmaxLayer : public UNglNeuralNetworkLayerBase
{
	GENERATED_BODY()

public:
	NGLNN_LAYER_CLASS_OBJECT_CREATE_FUNC_DEF(UNglSoftmaxLayer);

	// Sets default values for this actor's properties
	UNglSoftmaxLayer()
	{
		layer_ = TSharedPtr< NglSoftmaxLayer >(new NglSoftmaxLayer());
		setLayerCore(layer_);
	}

	// initialize layer
	UFUNCTION(BlueprintCallable)
		UNglSoftmaxLayer* Initialize(int numInput)
	{
		layer_->Initialize(numInput);
		return this;
	}
	// create and initialize layer
	UFUNCTION(BlueprintCallable, DisplayName = "Create NglSoftmaxLayer")
		static	UNglSoftmaxLayer* Create(int numInput)
	{
		return NewObject<UNglSoftmaxLayer>()->Initialize(numInput);
	}

	// load json
	bool LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer);

private:
	TSharedPtr< NglSoftmaxLayer > layer_;
};

// Affine Layer.
//	be also called FullConnected Layer.
//	アフィンレイヤ. 全結合レイヤとも呼ばれる.
UCLASS(BlueprintType)
class NGLNN_API UNglAffineLayer : public UNglNeuralNetworkLayerBase
{
	GENERATED_BODY()

public:
	NGLNN_LAYER_CLASS_OBJECT_CREATE_FUNC_DEF(UNglAffineLayer);

	// Sets default values for this actor's properties
	UNglAffineLayer()
	{
		layer_ = TSharedPtr< NglAffineLayer >(new NglAffineLayer());
		setLayerCore(layer_);
	}

	// initialize layer
	//	if you need initialize weight with random, set true for initRandomWeight.
	//	重みパラメータを乱数初期化する場合は initRandomWeight を true にする.
	UFUNCTION(BlueprintCallable)
		UNglAffineLayer* Initialize( int numInput, int numOutput, bool initRandomWeight = true )
	{
		layer_->Initialize(numInput, numOutput);
		if (initRandomWeight)
			layer_->InitializeWeightWithNormalDistribution();
		return this;
	}
	// create and initialize layer
	UFUNCTION(BlueprintCallable, DisplayName = "Create NglAffineLayer")
		static	UNglAffineLayer* Create(int numInput, int numOutput, bool initRandomWeight = true)
	{
		return NewObject<UNglAffineLayer>()->Initialize(numInput, numOutput, initRandomWeight);
	}

	// load json
	bool LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer);

private:
	TSharedPtr< NglAffineLayer > layer_;
};
//----------------------------------------------------------------------------------

// GRU Layer
//	Gated Recurrent Unit. reference current input and previous timestep input. (Not Full-BPTT)
//	ゲート付きリカレントユニット. 今回の入力と前回タイムステップの入力をもとに出力を計算する. 前回しか参照しないのでFull-BPTTではない.
UCLASS(BlueprintType)
class NGLNN_API UNglGruLayer : public UNglNeuralNetworkLayerBase
{
	GENERATED_BODY()

public:
	NGLNN_LAYER_CLASS_OBJECT_CREATE_FUNC_DEF(UNglGruLayer);

	// Sets default values for this actor's properties
	UNglGruLayer()
	{
		layer_ = TSharedPtr< NglGruLayer >(new NglGruLayer());
		setLayerCore(layer_);
	}

	// initialize layer
	//	if you need initialize weight with random, set true for initRandomWeight.
	//	重みパラメータを乱数初期化する場合は initRandomWeight を true にする.
	UFUNCTION(BlueprintCallable)
		UNglGruLayer* Initialize(int numInput, int numOutput, bool initRandomWeight = true)
	{
		layer_->Initialize(numInput, numOutput);
		if (initRandomWeight)
			layer_->InitializeWeightWithNormalDistribution();
		return this;
	}
	// create and initialize layer
	UFUNCTION(BlueprintCallable, DisplayName = "Create NglGruLayer")
		static	UNglGruLayer* Create(int numInput, int numOutput, bool initRandomWeight = true)
	{
		return NewObject<UNglGruLayer>()->Initialize(numInput, numOutput, initRandomWeight);
	}

	// save json.
	bool SaveJson(FJsonObject* jsonObject) const;
	// load json
	bool LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer);

private:
	TSharedPtr< NglGruLayer > layer_;
};
//----------------------------------------------------------------------------------

// Convolutional Layer.
//	CNN.
//	畳み込みレイヤ.
UCLASS(BlueprintType)
class NGLNN_API UNglConvolutionalLayer : public UNglNeuralNetworkLayerBase
{
	GENERATED_BODY()

public:
	NGLNN_LAYER_CLASS_OBJECT_CREATE_FUNC_DEF(UNglConvolutionalLayer);

	// Sets default values for this actor's properties
	UNglConvolutionalLayer()
	{
		layer_ = TSharedPtr< NglCnnLayer >(new NglCnnLayer());
		setLayerCore(layer_);
	}

	// initialize layer
	//	if you need initialize weight with random, set true for initRandomWeight.
	//	重みパラメータを乱数初期化する場合は initRandomWeight を true にする.
	UFUNCTION(BlueprintCallable)
		UNglConvolutionalLayer* Initialize(
			// size of shape at each dimension. for example, 2D Image which size are 32x16 is {32, 16}. 
			const TArray<int>& inputShape,
			// size of shape at each dimension. for example, 3-channel 2D Image which size are 32x16 is {32, 16, 3}. 
			// if this larger than inputShape, number of kernel is increased.
			const TArray<int>& outputShape,
			// radius of kernel at each dimension.
			// radius={1,1} -> kernel=1x1. radius={2,2} -> kernel=3x3. radius={3,3} -> kernel=5x5 
			const TArray<int>& kernelRadius,
			// kernel stride size at each dimension.
			const TArray<int>& strideShape,

			bool initRandomWeight = true)
	{
		layer_->Initialize( 
			(unsigned int*)(inputShape.GetData()), inputShape.Num(),
			(unsigned int*)(outputShape.GetData()), outputShape.Num(),
			(unsigned int*)(kernelRadius.GetData()), kernelRadius.Num(),
			(unsigned int*)(strideShape.GetData()), strideShape.Num());
		if (initRandomWeight)
			layer_->InitializeWeightWithNormalDistribution();
		return this;
	}
	// create and initialize layer
	UFUNCTION(BlueprintCallable, DisplayName = "Create NglConvolutionalLayer")
		static	UNglConvolutionalLayer* Create(
			// size of shape at each dimension. for example, 2D Image which size are 32x16 is {32, 16}. 
			const TArray<int>& inputShape,
			// size of shape at each dimension. for example, 3-channel 2D Image which size are 32x16 is {32, 16, 3}. 
			// if this larger than inputShape, number of kernel is increased.
			const TArray<int>& outputShape,
			// radius of kernel at each dimension.
			// radius={1,1} -> kernel=1x1. radius={2,2} -> kernel=3x3. radius={3,3} -> kernel=5x5 
			const TArray<int>& kernelRadius,
			// kernel stride size at each dimension.
			const TArray<int>& strideShape,
			bool initRandomWeight = true)
	{
		return NewObject<UNglConvolutionalLayer>()->Initialize(inputShape, outputShape, kernelRadius, strideShape, initRandomWeight);
	}

	// save json.
	bool SaveJson(FJsonObject* jsonObject) const;
	// load json
	bool LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer);

private:
	TSharedPtr< NglCnnLayer > layer_;
};
//----------------------------------------------------------------------------------



DECLARE_DELEGATE_RetVal(UNglNeuralNetworkLayerBase*, NglNeuralNetworkLayerCreateDelegate)

// カタログ
class NGLNN_API NglNeuralNetworkClassCatalog
{
public:
	static NglNeuralNetworkClassCatalog& GetInstance();

	// add Layer Create Func
	bool AddLayerCreateFunc( const FString& className, UNglNeuralNetworkLayerBase* (*static_self_create_method)() );
	// call Layer Create Func
	UNglNeuralNetworkLayerBase* CallLayerCreateFunc(const FString& className);


private:
	NglNeuralNetworkClassCatalog();
	~NglNeuralNetworkClassCatalog();

private:
	// 禁止
	NglNeuralNetworkClassCatalog(const NglNeuralNetworkClassCatalog &) = delete;
	NglNeuralNetworkClassCatalog& operator=(const NglNeuralNetworkClassCatalog &) = delete;
	NglNeuralNetworkClassCatalog(NglNeuralNetworkClassCatalog &&) = delete;
	NglNeuralNetworkClassCatalog& operator=(NglNeuralNetworkClassCatalog &&) = delete;

private:
	// レイヤクラス名( 先頭の U を除いた )からそのレイヤクラスオブジェクトを生成するファンクタへのマップ
	TMap<FString, NglNeuralNetworkLayerCreateDelegate> layerCreateFuncMap_;
};
//----------------------------------------------------------------------------------


//----------------------------------------------------------------------------------
#undef NGLNN_LAYER_CLASS_OBJECT_CREATE_FUNC_DEF
//----------------------------------------------------------------------------------

/*

// Dummy Class
UCLASS()
class NGLNN_API ANglNeuralNetworkComponents : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ANglNeuralNetworkComponents();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	
	
};

*/

