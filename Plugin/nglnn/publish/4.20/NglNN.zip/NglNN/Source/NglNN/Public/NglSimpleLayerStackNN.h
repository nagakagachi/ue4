﻿/*
	Copyright (c) 2018 Taro Horikawa

	twitter@nagakagachi
*/
#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "NglNeuralNetworkComponents.h"

#include "NglSimpleLayerStackNN.generated.h"

/**
 *	Layer stack Neural Network class.
 *	"Layers" are Affine, Sigmoid, ReLU and other.
 * 
 *	レイヤースタック型のニューラルネットワーククラス.
 *	"レイヤ" にはAffineレイヤやSigmoid,ReLU等がある.
 */
UCLASS(BlueprintType)
class NGLNN_API UNglSimpleLayerStackNN : public UObject
{
	GENERATED_BODY()

public:
	UNglSimpleLayerStackNN();
	virtual void BeginDestroy();

public:
	// remove all layers and reset param.
	// 登録されたレイヤをすべて削除し,パラメータをリセットする.
	UFUNCTION(BlueprintCallable)
		void Cleanup()
	{
		nn_.Cleanup();
		layers_.Empty();
	}
	// add new layer to output side.
	// レイヤを出力側に追加接続.
	UFUNCTION(BlueprintCallable)
		void AddLayer(UNglNeuralNetworkLayerBase* layer);

	// get result output of output-layer at last forward propagation.
	// 最新の順伝搬の出力を取得.
	UFUNCTION(BlueprintPure)
		TArray<float> GetOutput()
	{
		TArray<float> tmp(nn_.GetOutputActivities(), nn_.NumOutputLayerNeuron());
		return tmp;
	}

	// get layer count of network.
	// 総レイヤ数を取得.
	UFUNCTION(BlueprintPure)
		int NumLayer() const
	{
		return layers_.Num();
	}
	// remove layer object with layer index. return value is removed layer object.
	//	This method is used to move layers to other networks. e.g. src.GetLayer(), dst.AddLayer(), src.RemoveLayer().
	// レイヤ番号を指定してレイヤオブジェクトを除去. 戻り値として除去されたレイヤオブジェクトを返す.
	//	このメソッドはレイヤを別のネットワークに移す際に使われる.
	UFUNCTION(BlueprintPure)
		UNglNeuralNetworkLayerBase* RemoveLayer(int index)
	{
		if (0 > index || NumLayer() <= index)
			return NULL;
		UNglNeuralNetworkLayerBase* layer = layers_[index];
		layers_.RemoveAt(index);
		return layer;
	}

	// get layer object with layer index.
	// レイヤ番号を指定してレイヤオブジェクトを取得.
	UFUNCTION(BlueprintPure)
		UNglNeuralNetworkLayerBase* GetLayer(int index)
	{
		if (0 > index || NumLayer() <= index)
			return NULL;
		return layers_[index];
	}
	// get count of input layer neuron.
	// ネットワークの入力層のサイズ(ユニット数)を取得.
	UFUNCTION(BlueprintPure)
		int NumInputLayerNeuron() const
	{
		return nn_.NumInputLayerNeuron();
	}
	// get count of output layer neuron.
	// ネットワークの出力層のサイズ(ユニット数)を取得.
	UFUNCTION(BlueprintPure)
		int NumOutputLayerNeuron() const
	{
		return nn_.NumOutputLayerNeuron();
	}

	// reset network inner state. e.g. RNN, GRU or LSTM. you can use at restart game.
	// ゲームのリスタート時などのために, ネットワークの内部状態をリセットする. 
	// RNNやGRU, LSTM等直前の状態を保持するネットワークの状態が対象.
	UFUNCTION(BlueprintCallable)
		void ResetInnerState()
	{
		nn_.ResetInnerState();
	}

	// run forward propagation.
	// 順伝搬を実行.
	UFUNCTION(BlueprintCallable)
		void Forward(
			UPARAM(DisplayName = "input data") const TArray<float>& input);


	// change network mode to Train. default is Inference for reasons of low memory usage.
	// ネットワークを学習モードへ切り替え. デフォルトはメモリ使用量の少ない推論モード.
	UFUNCTION(BlueprintCallable)
		void SetToTrainMode()
	{
		nn_.SetToTrainMode();
	}
	// change network mode to Inference. default is Inference for reasons of low memory usage.
	// ネットワークを推論モードへ切り替え. デフォルトはメモリ使用量の少ない推論モード.
	UFUNCTION(BlueprintCallable)
		void SetToInferenceMode()
	{
		nn_.SetToInferenceMode();
	}
	// return true if network is TrainMode.
	// ネットワークが学習モードの場合に真を返す.
	UFUNCTION(BlueprintPure)
		bool IsTrainMode() const { return nn_.IsTrainMode(); }

	// learning rate.
	// 学習係数.
	UFUNCTION(BlueprintCallable)
		void SetLearningRate(float rate = 0.01) { nn_.SetLearningRate(rate); }
	// learning rate.
	// 学習係数.
	UFUNCTION(BlueprintPure)
		float GetLearningRate() const { return nn_.GetLearningRate(); }

	// learning momentum.
	// 学習時の慣性値.
	UFUNCTION(BlueprintCallable)
		void SetLearningMomentum(float momentum = 0.1) { nn_.SetLearningMomentum(momentum); }
	// learning momentum.
	// 学習時の慣性値.
	UFUNCTION(BlueprintPure)
		float GetLearningMomentum() const { return nn_.GetLearningMomentum(); }

	// L2 Regularization rate.
	// L2正則化係数.
	UFUNCTION(BlueprintCallable)
		void SetL2RegularizationRate(float rate = 0.001) { nn_.SetL2RegularizationRate(rate); }
	// L2 Regularization rate.
	// L2正則化係数.
	UFUNCTION(BlueprintPure)
		float GetL2RegularizationRate() const { return nn_.GetL2RegularizationRate(); }

	// execute train with input and teacher data.
	// 入力データと教師データを与えて学習を実行.
	UFUNCTION(BlueprintCallable)
		void Train(
			UPARAM(DisplayName = "input data") const TArray<float>& input
			, UPARAM(DisplayName = "teacher data") const TArray<float>& teach);

	// get cost value at last train.
	// 最期に実行した学習時のコスト関数の値
	UFUNCTION(BlueprintPure)
		float GetLastTrainCost() const
	{
		return nn_.GetLastTrainCost();
	}



	// Save Network to Json. if only filename, save to ProjectSavedDir.
	// ネットワークをJsonファイルに保存. ファイル名のみを指定した場合はProjectSavedDirに保存される.
	UFUNCTION(BlueprintCallable)
		bool SaveJson(const FString& inputFilePath);

	// Load Network from Json and Construct Network. if only filename, load from ProjectSavedDir.
	// Jsonファイルからネットワークを構築. ファイル名のみを指定した場合はProjectSavedDirから検索される.
	UFUNCTION(BlueprintCallable)
		bool LoadJson(const FString& inputFilePath);


protected:
	// layer object holder.
	// 
	// BPで追加されたレイヤを保持
	// UPROPERTY指定されたTArrayがポインタを保持するので,要素を除去して参照がなくなった時にガベコレ対象になるはず
	// 別のNglSimpleLayerStackNNにレイヤを移すような運用も可能なはず(nn_が持っているレイヤ実体も移動するのを忘れないように)
	UPROPERTY()
		TArray< class UNglNeuralNetworkLayerBase* > layers_;

	// NeuralNetwork Core.
	NglSimpleLayerStackNN nn_;
};
