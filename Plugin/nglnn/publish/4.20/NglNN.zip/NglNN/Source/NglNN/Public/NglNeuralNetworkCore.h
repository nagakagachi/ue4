﻿/*
	Copyright (c) 2018 Taro Horikawa

	twitter@nagakagachi
*/

#pragma once

#include "CoreMinimal.h"


//--------------------------------------------------------
// Dual Number struct
//
// a + b[e]
// [e]*[e] = 0
// 
// conjugate 
// a + b[e] <->  a - b[e]
//
struct NglDualNumber
{
private:
	float a_;
	float b_;
public:
	using this_type = NglDualNumber;
public:
	static float EPSILON_VAL()
	{
		return 1.0e-8;
	}
public:
	NglDualNumber() : a_(0), b_(0) {}
	NglDualNumber(float a, float b = float(0)) : a_(a), b_(b) {}
	const this_type& operator =(const float& rhs)
	{
		a_ = rhs;
		return *this;
	}
	// negative sign
	this_type operator - () const
	{
		return this_type(-a_, -b_);
	}
	// this += x
	this_type& operator += (const this_type& rhs)
	{
		a_ += rhs.a_;
		b_ += rhs.b_;
		return *this;
	}
	// this -= x
	this_type& operator -= (const this_type& rhs) {
		a_ -= rhs.a_;
		b_ -= rhs.b_;
		return *this;
	}
	// this *= x
	this_type& operator *= (const this_type& rhs) {
		b_ = (b_ * rhs.a_ + a_ * rhs.b_);
		a_ *= rhs.a_;
		return *this;
	}
	// this /= x
	this_type& operator /= (const this_type& rhs)
	{
		// 共役を利用して分母を実数にしている
		b_ = (b_ * rhs.a_ - a_ * rhs.b_) / (rhs.a_ * rhs.a_);
		a_ /= rhs.a_;
		return *this;
	}
	// this + x
	this_type operator + (const this_type& rhs) const
	{
		return this_type(*this) += rhs;
	}
	// this - x
	this_type operator - (const this_type& rhs) const
	{
		return this_type(*this) -= rhs;
	}
	// this * x
	this_type operator * (const this_type& rhs) const
	{
		return this_type(*this) *= rhs;
	}
	// this / x
	this_type operator / (const this_type& rhs) const
	{
		return this_type(*this) /= rhs;
	}
	// sin(x)
	static this_type sin(const this_type& x)
	{
		return this_type(FMath::Sin(x.a_), FMath::Cos(x.a_) * x.b_);
	}
	// cos(x)
	static this_type cos(const this_type& x)
	{
		return this_type(FMath::Cos(x.a_), -FMath::Sin(x.a_) * x.b_);
	}
	// tan(x)
	static this_type tan(const this_type& x)
	{
		float t = FMath::Tan(x.a_);
		float c = FMath::Cos(x.a_);
		return this_type(t, x.b_ / (c*c));
	}
	// tanh(x)
	static this_type tanh(const this_type& x)
	{
#if 1
		// limit input range because result become NaN.
		const float expRange = 20.0f;
		const this_type arg_x = x * 2.0;
		const float limited_a = FMath::Min(FMath::Max(arg_x.a_, -expRange), expRange);
		const float a = FMath::Exp(limited_a);
		const this_type e2x(a, a * arg_x.b_);
		NglDualNumber debug_ = NglDualNumber::exp(x * 2.0f);
#else
		NglDualNumber e2x = NglDualNumber::exp(x * 2.0f);
#endif
		return (e2x - 1.0) / (e2x + 1.0);
	}
	// e ^ x
	static this_type exp(const this_type& x)
	{
		const float a = FMath::Exp(x.a_);
		return this_type(a, a * x.b_);
	}
	// loge(x)
	static this_type loge(const this_type& x)
	{
		return this_type(FMath::Loge(x.a_), x.b_ / x.a_);
	}
	// log2(x)
	static this_type log2(const this_type& x)
	{
		return this_type(FMath::Log2(x.a_), x.b_ / (x.a_ * FMath::Loge(2.0)));
	}
	// sqrt(x)
	static this_type sqrt(const this_type& x)
	{
		float a = FMath::Sqrt(x.a_);
		return this_type(a, x.b_ / (2.0 * a));
	}
	// pow( x,y ) = x ^ y
	static this_type pow(const this_type& x, const this_type& y)
	{
		float p = FMath::Pow(x.a_, y.a_);

		float da = y.a_ * FMath::Pow(x.a_, y.a_ - 1.0);
		// limit input range because result become NaN.
		float db = p * FMath::Loge(FMath::Max(EPSILON_VAL(), x.a_));
		return this_type(p, da*x.b_ + db * y.b_);
	}
	// abs(x)
	static this_type abs(const this_type& x)
	{
		return this_type(FMath::Abs(x.a_), (0 <= x.a_) ? 1.0 * x.b_ : -1.0 * x.b_);
	}
	// max(x,y)
	static this_type max(const this_type& x, const this_type& y)
	{
		return (x.a_ > y.a_) ? x : y;
	}
	// min(x,y)
	static this_type min(const this_type& x, const this_type& y)
	{
		return (x.a_ < y.a_) ? x : y;
	}
	// sigmoid
	static this_type sigmoid(const this_type& x)
	{
		const this_type one(1.0);
#if 1
		// limit input range because result become NaN.
		const float sigmoidRange = 30.0f;
		const this_type arg_x = -x;
		const float limited_a = FMath::Min(FMath::Max(arg_x.a_, -sigmoidRange), sigmoidRange);
		const float a = FMath::Exp(limited_a);
		const this_type expVal(a, a * arg_x.b_);
		return one / (one + expVal);
#else
		return one / (one + this_type::exp(-x));
#endif
	}
	// ReLU
	static this_type ReLU(const this_type& x)
	{
		return this_type::max(this_type(0.0), x);
	}
	// ----------------------------------------------------------------------
	// if Function Derivative with respect to This Variation, set True.
	// 偏微分対象とする場合真
	// f(x,y) に関して x の偏微分を得たい場合は,
	// x.DerivativeRespect(true)
	// y.DerivativeRespect(false)
	// として
	// f( x,y ) を実行する
	const this_type& DerivativeRespect(bool v = true)
	{
		b_ = (v) ? 1.0 : 0.0;
		return *this;
	}
	// 値
	float Value() const
	{
		return a_;
	}
	// 微分値
	float Differential() const
	{
		return b_;
	}
};

// ----------------------------------------------------------------------


class NglMathUtil
{
public:
	//  Box–Muller's method
	//		mu		: Average
	//		sigma	: Standard deviation 
	static float NormalRandom(const float mu, const float sigma);

	static void FillTArray(TArray<float>& target, const float val)
	{
		const int N = target.Num();
		for (int i = 0; i < N; ++i)
			target[i] = val;
	}
};



// ----------------------------------------------------------------------
// Optimizer
class NglOptimizerBase
{
public:
	NglOptimizerBase()
	{
	}
	virtual ~NglOptimizerBase()
	{
	}
	virtual void Reset() = 0;
	virtual void operator()(TArray<float>& targetParam, const TArray<float>& paramDelta,
		float paramDeltaRate = 1.0f, float updateRate = 0.001f, float weightDecay = 0.0f) = 0;
};

// momentum SGD
class NglOptimizerMomentumSGD : public NglOptimizerBase
{
public:
	NglOptimizerMomentumSGD();
	~NglOptimizerMomentumSGD();
	void Initialize(float momentum);
	void Reset();
	void SetMomentum(float momentum);
	void operator()(TArray<float>& targetParam, const TArray<float>& paramDelta,
		float paramDeltaRate = 1.0f, float updateRate = 0.001f, float weightDecay = 0.0f);

protected:
	float momentum_;
	TArray<float> moment_;
};
// Adam
class NglOptimizerAdam : public NglOptimizerBase
{
public:
	NglOptimizerAdam();
	~NglOptimizerAdam();
	void Initialize(float beta1 = 0.9f, float beta2 = 0.999f);
	void Reset();
	void SetParam(float beta1 = 0.9f, float beta2 = 0.999f);
	void operator()(TArray<float>& targetParam, const TArray<float>& paramDelta,
		float paramDeltaRate = 1.0f, float updateRate = 0.001f, float weightDecay = 0.0f);

protected:
	unsigned int t_;
	float beta1_;
	float beta2_;
	TArray<float> moment1st_;
	TArray<float> moment2nd_;
};

// ----------------------------------------------------------------------

/*

*/
//--------------------------------------------------------
// 活性化関数ファンクタ
class NglActivationFuncBase
{
public:
	virtual NglDualNumber operator()(float arg) = 0;
};
// sigmoid 活性化関数
class NglActivationFuncSigmoid : public NglActivationFuncBase
{
public:
	virtual NglDualNumber operator()(float arg)
	{
		// 引数に関して偏微分する設定で計算実行
		return NglDualNumber::sigmoid(NglDualNumber(arg).DerivativeRespect());
	}
};
// ReLU 活性化関数
class NglActivationFuncReLU : public NglActivationFuncBase
{
public:
	virtual NglDualNumber operator()(float arg)
	{
		// 引数に関して偏微分する設定で計算実行
		return NglDualNumber::ReLU(NglDualNumber(arg).DerivativeRespect());
	}
};

//--------------------------------------------------------
// コスト関数ファンクタ基底 現状はForward自動微分で対応
class NglCostFuncBase
{
public:
	NglCostFuncBase() {}
	virtual ~NglCostFuncBase() {}
	// Forwardモード自動微分でのコスト関数は出力層のニューロン数と同じ数だけ実行してそれぞれのニューロンについての勾配を計算するために
	// NglDualNumber配列を引数とする
	virtual NglDualNumber operator()(const TArray<NglDualNumber>& arg, const TArray<float>& teach) = 0;
};
// 二乗誤差コスト関数
class NglCostFuncSquareError : public NglCostFuncBase
{
public:
	~NglCostFuncSquareError() {}
	// 偏微分を得たい入力に関しては DerivativeRespect() で偏微分計算をするように設定しておく必要がある
	NglDualNumber operator()(const TArray<NglDualNumber>& arg, const TArray<float>& teacherSignal)
	{
		// 二乗誤差やクロスエントロピーの arg[i]に関する偏微分は 
		// arg[i] - teacherSignal[i]
		// であるが、一応任意の関数を自動微分で偏微分できることを示すために素直に計算している
		NglDualNumber ret = 0;
		const unsigned int minCnt = FMath::Min(arg.Num(), teacherSignal.Num());
		for (unsigned int i = 0; i < minCnt; ++i)
		{
			ret += NglDualNumber::pow(arg[i] - teacherSignal[i], 2.0);
		}
		return ret;
	}
};



//--------------------------------------------------------
// ネットワークレイヤ基底
class NglNeuralNetworkLayerBase
{
public:
	NglNeuralNetworkLayerBase()
	{
		isTrainMode_ = false;
		isInnerStateUpdatable_ = true;
	}
	virtual ~NglNeuralNetworkLayerBase() {};


	// ----------------------------------------------------------------------------------------------------------------
	// calc layer neuron activity with forward
	// calc output_ from input. 
	// 入力値から出力バッファを計算する
	virtual void Forward(const float* input, unsigned int size) = 0;

	// for Training Method.
	// calc weightDeltaMatrix_ and backPropagationGradient_.
	// 逆伝搬. 引数は出力側から伝搬してきた勾配ベクトル( レイヤの出力ニューロン数と一致 )
	// weightの更新値とこのレイヤの前段に伝搬する勾配を計算する
	virtual void BackPropagation(const float* backPropGradient, unsigned int size) = 0;

	// Called at mode is changed. Train-Mode is True, Inference-Mode is False. inplement on inherit class.
	virtual void OnChangeTrainMode(bool toTrainMode);

	// 内部状態を明示的にリセットする. RNNやGRU,LSTM等の内部状態を持つレイヤはその状態をリセットする. 派生クラスで実装.
	// explicit reset inner state ( RNN, GRU, LSTM ). inplement on inherit class.
	virtual void ResetInnerState() {}
	// ----------------------------------------------------------------------------------------------------------------

	// calc layer neuron activity with forward
	void Forward(const TArray<float>& input);

	// getter
	unsigned int NumInput() const;
	const float* GetInput() const;
	float* GetInput();
	unsigned int NumOutput() const;
	const float* GetOutput() const;
	float* GetOutput();

	// get and set weights.
	// override in inhelit class. ex full-connected layer, CNN layer. 
	unsigned int NumWeight() const;
	const float* GetWeightPtr() const;
	float* GetWeightPtr();
	TArray<float>& GetWeight();
	const TArray<float>& GetWeight() const;
	float GetWeightAtIndex(unsigned int index) const;
	// set weight directly. isForce is force set even if different num of weight.
	void SetWeight(const float* weightArray, unsigned int numWeight, bool isForce);
	void SetWeightAtIndex(unsigned int index, float weight);

	// ネットワークの学習モードと推論モードを切り替え. デフォルトはメモリ使用量の少ない推論モード
	// change network mode with Train or Inference. default is Inference for reasons of low memory usage.
	bool IsTrainMode() const { return isTrainMode_; }
	void SetToTrainMode();
	void SetToInferenceMode();

	// for innner state.
	// 内部状態に関するメソッド
	bool IsInnerStateUpdatable() const { return isInnerStateUpdatable_; }
	void SetInnerStateUpdatable(bool flag) { isInnerStateUpdatable_ = flag; }

	// ----------------------------------------------------------------------------------------------------------------
	// for Training Method.
	//
	// BackProp Gradient to Prev Layer.
	// 逆伝搬時に上流レイヤに伝搬する勾配を取得
	const float* GetBackPropagationGradient() const;
	unsigned int NumBackPropagationGradient() const;

	// apply weight delta to weight matrix that calculated by backprop.
	virtual void UpdateWeight(int miniBatchSize, float learningRate, float momentum, float regularizationRate);
	// calc Regularization Cost.
	virtual float CalcL2RegularizationCost(float regularizationRate) const;

	// for gradient checking debug.
	// gradient checking のための誤差の差分をセットする. GradientCheckingTargetになっている重みのみが対象になる
	void SetGradientCheckingDifference( unsigned int weightIndex, float diff );
	float GetGradientCheckingDifference( unsigned int weightIndex) const;
	float GetWeightGradientAtIndex(unsigned int index) const;
	// ----------------------------------------------------------------------------------------------------------------

private:
	// layer mode ( train or inference )
	bool isTrainMode_;
	// A flag indicating whether or not the state of a layer having an internal state can be updated
	bool isInnerStateUpdatable_;

protected:
	// init layer-base buffer. (e.g. input,output and weight buffer. 
	void InitializeBase( unsigned int inputCount, unsigned int outputCount, unsigned int weightCount );

private:
	// input buffer.
	TArray<float> input_;
	// neuron activity of Forwad result.
	TArray<float> output_;
	// weight param matrix.
	TArray<float> weightMatrix_;


protected:
	// ----------------------------------------------------------------------------------------------------------------
	// for Training Member.	学習用のメンバ
	//
	// backpropagation gradient to upstream layer.
	TArray<float>	backPropagationGradient_;

	// weight matrix update delta 
	TArray<float>	weightDeltaMatrix_;

	NglOptimizerMomentumSGD	optimizerMomentumSGD_;
	NglOptimizerAdam		optimizerAdam_;

	// ----------------------------------------------------------------------------------------------------------------
};
inline
void NglNeuralNetworkLayerBase::SetToTrainMode() 
{ 
	if (IsTrainMode())
		return;
	isTrainMode_ = true;
	OnChangeTrainMode(isTrainMode_);
}
inline
void NglNeuralNetworkLayerBase::SetToInferenceMode()
{ 
	if (!IsTrainMode())
		return;
	isTrainMode_ = false;
	OnChangeTrainMode(isTrainMode_);
}
// ----------------------------------------------------------------------------------------------------------------


// ----------------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------------
// 活性化レイヤ とりあえずReLU実装をしてから各種活性化関数バリエーションの設計をする
// 活性化レイヤ基底
class NglActivationLayer : public NglNeuralNetworkLayerBase
{
public:
	NglActivationLayer();
	virtual ~NglActivationLayer();

	// ----------------------------------------------------------------------------------------------------------------
	// Activation. do Implement on Inherit Class. return gradient with NglDualNumber.
	// 活性化処理. 派生クラスでそれぞれ実装する. 二重数で勾配を返すように.
	virtual NglDualNumber Activation(float arg) 
	{
		// 既定ではそのまま返す. 勾配は 1
		return NglDualNumber(arg, 1.0f); 
	};
	// ----------------------------------------------------------------------------------------------------------------

	// ----------------------------------------------------------------------------------------------------------------
	// init layer memory
	// set neuron activation functor
	bool Initialize(unsigned int numInput);

	// calc layer neuron activity with forward
	void Forward(const float* input, unsigned int size);

	// Call at change mode. Train-Mode is True, Inference-Mode is False.
	// change network mode with Train or Inference. default is Inference for reasons of low memory usage.
	// ネットワークの学習モードと推論モードを切り替え. デフォルトはメモリ使用量の少ない推論モード
	void OnChangeTrainMode(bool toTrainMode);

	// BackPropagation. add learcning delta to update-matrix. practical update is UpdateWeight().
	// 逆伝搬. 引数は出力側から伝搬してきた勾配ベクトル( レイヤの出力ニューロン数と一致 )
	// 重み行列の更新値にデルタを足しこみ、前のレイヤへ伝搬する勾配を計算する.
	// 実際の重み行列の更新はUpdateWeight()を実行することで処理される.
	void BackPropagation(const float* backPropGradient, unsigned int size);


	// apply weight delta to weight matrix that calculated by backprop.
	// ignore activation layer bias.
	virtual void UpdateWeight( int miniBatchSize, float learningRate, float momentum, float regularizationRate);
	// calc Regularization Cost.
	// ignore activation layer bias.
	virtual float CalcL2RegularizationCost(float regularizationRate) const;

private:
	// ----------------------------------------------------------------------------------------------------------------
	// for Training Member.	学習用のメンバ
	//
	TArray<float> outputDifferential_;
};


// ReLU レイヤ
// output == 0 ( if input<=0
// output == 0 ( if input>0
class NglReluLayer : public NglActivationLayer
{
public:
	NglReluLayer() {}
	~NglReluLayer() {}
	// ----------------------------------------------------------------------------------------------------------------
	NglDualNumber Activation(float arg)
	{
		return NglDualNumber::ReLU(NglDualNumber(arg).DerivativeRespect());
	};
	// ----------------------------------------------------------------------------------------------------------------
};

// Sigmoid レイヤ
// 0 <= output <= 1
class NglSigmoidLayer : public NglActivationLayer
{
public:
	NglSigmoidLayer() {}
	~NglSigmoidLayer() {}
	// ----------------------------------------------------------------------------------------------------------------
	NglDualNumber Activation(float arg)
	{
		return NglDualNumber::sigmoid(NglDualNumber(arg).DerivativeRespect());
	};
	// ----------------------------------------------------------------------------------------------------------------
};

// HyperbolicTangent レイヤ ( tanh )
// -1 <= output <= 1
// 中心ゼロで値域が -1  +1,
class NglTanhLayer : public NglActivationLayer
{
public:
	NglTanhLayer() {}
	~NglTanhLayer() {}
	// ----------------------------------------------------------------------------------------------------------------
	NglDualNumber Activation(float arg)
	{
		/*
			tanh = ( exp(x) + exp(-x) ) / ( exp(x) + exp(-x) )
			     = ( exp(2x) - 1 ) / ( exp(2x) + 1 )
		*/
		//NglDualNumber x = NglDualNumber(arg).DerivativeRespect();
		//NglDualNumber e2x = NglDualNumber::exp(x * 2.0f);
		//return (e2x - 1.0) / (e2x + 1.0);

		return NglDualNumber::tanh(NglDualNumber(arg).DerivativeRespect());
	};
	// ----------------------------------------------------------------------------------------------------------------
};
// Softplus レイヤ
// 0 <= output <= 1
class NglSoftplusLayer : public NglActivationLayer
{
public:
	NglSoftplusLayer() {}
	~NglSoftplusLayer() {}
	// ----------------------------------------------------------------------------------------------------------------
	NglDualNumber Activation(float arg)
	{
		NglDualNumber x = NglDualNumber(arg).DerivativeRespect();
		return NglDualNumber::loge( NglDualNumber::exp(x) + 1.0 );
	};
	// ----------------------------------------------------------------------------------------------------------------
};

// ----------------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------------


// ----------------------------------------------------------------------------------------------------------------
// Softmax Layer ( for multiclass classification )
// N個の出力が 0 - 1の範囲で、総和が 1 であるような確率として扱える出力をする
// exi / ( sum( ex ) )
class NglSoftmaxLayer : public NglNeuralNetworkLayerBase
{
public:
	NglSoftmaxLayer();
	virtual ~NglSoftmaxLayer();

	// init layer memory
	// set neuron activation functor
	bool Initialize(unsigned int numInput);

	// calc layer neuron activity with forward
	void Forward(const float* input, unsigned int size);

	// Call at change mode. Train-Mode is True, Inference-Mode is False.
	// change network mode with Train or Inference. default is Inference for reasons of low memory usage.
	// ネットワークの学習モードと推論モードを切り替え. デフォルトはメモリ使用量の少ない推論モード
	void OnChangeTrainMode(bool toTrainMode);

	// ----------------------------------------------------------------------------------------------------------------
	// for Training Method.
	//
	// BackPropagation. add learcning delta to update-matrix. practical update is UpdateWeight().
	// 逆伝搬. 引数は出力側から伝搬してきた勾配ベクトル( レイヤの出力ニューロン数と一致 )
	// 重み行列の更新値にデルタを足しこみ、前のレイヤへ伝搬する勾配を計算する.
	// 実際の重み行列の更新はUpdateWeight()を実行することで処理される.
	void BackPropagation(const float* backPropGradient, unsigned int size);

protected:
	TArray<float> outputDifferential_;
};


// ----------------------------------------------------------------------------------------------------------------
// Affine Layer ( Full Connected Layer )
// 全結合レイヤ( 今風にいうと Affine Layer らしいよ )
class NglAffineLayer : public NglNeuralNetworkLayerBase
{
public:
	NglAffineLayer();
	virtual ~NglAffineLayer();

	// init layer memory
	// set neuron activation functor
	bool Initialize(unsigned int numInput, unsigned int numOutput);

	// calc layer neuron activity with forward
	void Forward(const float* input, unsigned int size);
	
	// Call at change mode. Train-Mode is True, Inference-Mode is False.
	// change network mode with Train or Inference. default is Inference for reasons of low memory usage.
	// ネットワークの学習モードと推論モードを切り替え. デフォルトはメモリ使用量の少ない推論モード
	void OnChangeTrainMode( bool toTrainMode );

	// ----------------------------------------------------------------------------------------------------------------
	// for Training Method.
	//
	// init weight by random.
	void InitializeWeightWithNormalDistribution();

	// BackPropagation. add learcning delta to update-matrix. practical update is UpdateWeight().
	// 逆伝搬. 引数は出力側から伝搬してきた勾配ベクトル( レイヤの出力ニューロン数と一致 )
	// 重み行列の更新値にデルタを足しこみ、前のレイヤへ伝搬する勾配を計算する.
	// 実際の重み行列の更新はUpdateWeight()を実行することで処理される.
	void BackPropagation(const float* backPropGradient, unsigned int size);

protected:

};


// ----------------------------------------------------------------------------------------------------------------
// GRU Layer ( Gated Recurrent Unit Layer )
// ゲート付き再起ユニットレイヤ
//
//	weightsには更新ゲート、リセットゲート、候補ゲートの３つに関してそれぞれ Wu, Uu, Wr, Ur, Wc, Uc の6つの行列を埋め込み配置する
//
//	Wu : numOutput * numInput
//	Uu : numOutput * numOutput
//	Wr : numOutput * numInput
//	Ur : numOutput * numOutput
//	Wc : numOutput * numInput
//	Uc : numOutput * numOutput
//
//	Wは入力に掛け合わされ、Uは前回のユニット出力に掛け合わされる
//
// 以下によるとUは直行行列として初期化するのが良いらしい
// Wのほうは普通に正規分布でよいかな
//	http://www.cs.tau.ac.il/~joberant/teaching/advanced_nlp_spring_2017/files/chris_gru_lstm.pdf
//
class NglGruLayer : public NglNeuralNetworkLayerBase
{
public:
	enum EWEIGHT_KIND : int
	{
		UPDATE_INPUT = 0,
		RESET_INPUT,
		CANDIDATE_INPUT,
		UPDATE_RECURRENT,
		RESET_RECURRENT,
		CANDIDATE_RECURRENT,

		EWEIGHT_KIND_MAX
	};
public:
	NglGruLayer();
	virtual ~NglGruLayer();

	// init layer memory
	// set neuron activation functor
	bool Initialize(unsigned int numInput, unsigned int numOutput);

	// calc layer neuron activity with forward
	void Forward(const float* input, unsigned int size);

	// Call at change mode. Train-Mode is True, Inference-Mode is False.
	// change network mode with Train or Inference. default is Inference for reasons of low memory usage.
	// ネットワークの学習モードと推論モードを切り替え. デフォルトはメモリ使用量の少ない推論モード
	void OnChangeTrainMode(bool toTrainMode);

	// explicit reset inner state ( RNN, GRU, LSTM ). inplement on inherit class.
	// 内部状態を明示的にリセットする. RNNやGRU,LSTM等の内部状態を持つレイヤはその状態をリセットする. 派生クラスで実装.
	void ResetInnerState();

	unsigned int NumGateWeight(EWEIGHT_KIND kind) const;
	unsigned int GetGateWeightHeadIndex(EWEIGHT_KIND kind) const;
	unsigned int NumGateInput(EWEIGHT_KIND kind) const;
	unsigned int NumGateOutput(EWEIGHT_KIND kind) const;

	// ----------------------------------------------------------------------------------------------------------------
	// for Training Method.
	//
	// init weight by random.
	void InitializeWeightWithNormalDistribution();

	// BackPropagation. add learcning delta to update-matrix. practical update is UpdateWeight().
	// 逆伝搬. 引数は出力側から伝搬してきた勾配ベクトル( レイヤの出力ニューロン数と一致 )
	// 重み行列の更新値にデルタを足しこみ、前のレイヤへ伝搬する勾配を計算する.
	// 実際の重み行列の更新はUpdateWeight()を実行することで処理される.
	void BackPropagation(const float* backPropGradient, unsigned int size);

protected:
	// weight information of each gate.
	// ゲート別の情報を保持する
	unsigned int weightMatrixSizeArray_[EWEIGHT_KIND_MAX];
	unsigned int weightMatrixHeadArray_[EWEIGHT_KIND_MAX];
	struct
	{
		unsigned int numInput_;
		unsigned int numOutput_;
	} gateInOutSize_[EWEIGHT_KIND_MAX];

	// for recurrent gate. 
	// ゲート付き再帰のために必要なメンバ
	TArray<float>			outputPrev_;
	TArray<NglDualNumber>	outputUpdateGate_;
	TArray<NglDualNumber>	outputResetGate_;
	TArray<NglDualNumber>	outputCandidateGate_;

	// 学習用メンバ
	TArray<float>			resetGateBackPropGradient_;
};


// -----------------------------------------------------------------------------------
// integer position
struct NglVoxelPosition
{
	friend class NglShape;

	NglVoxelPosition();
	NglVoxelPosition(int numDimension);
	NglVoxelPosition(const int* pos, int numDimension);
	void setPos(int dimension, int posD);
	void setPos(const int* pos, int numDimension, bool fillTailByZero = true);
	int getPos(int dimension) const;
	int numDimension() const { return numDimension_; }
	int* getPosPtr() { return pos_.GetData(); }
	const int* getPosPtr() const { return pos_.GetData(); }
	const TArray<int>& getPosition() const { return pos_; }
	//
	void setAll(int value);
	// 
	NglVoxelPosition& operator=(const NglVoxelPosition& obj);
	NglVoxelPosition& operator+=(const NglVoxelPosition& obj);
	NglVoxelPosition& operator-=(const NglVoxelPosition& obj);
	NglVoxelPosition& operator*=(const NglVoxelPosition& obj);
	NglVoxelPosition operator+(const NglVoxelPosition& obj) const;
	NglVoxelPosition operator-(const NglVoxelPosition& obj) const;
	NglVoxelPosition operator*(const NglVoxelPosition& obj) const;

	bool lessEqualAllThan(const NglVoxelPosition& obj);
	bool lessAllThan(const NglVoxelPosition& obj);

private:
	void resize(int numDimension);

private:
	int numDimension_;
	TArray<int> pos_;
};
// ----------------------------------------------------------------------
// shape information.
class NglShape
{
public:
	NglShape();
	NglShape(int numDimension);
	NglShape(int* dimensionSizeArray, int dimensionSizeArraySize);
	void setShape(int dimensionIndex, int dimensionSize);
	void setShape(int* dimensionSizeArray, int dimensionSizeArraySize);
	int numDimension() const { return shape_.Num(); }
	int getDimensionSize(int index) const;
	const int* getDimensionSizeArrayPtr() const { return shape_.GetData(); }
	const TArray<int>& getDimensionSizeArray() const { return shape_; }

	// dim0Size * dim1Size * ... dimNSize.
	int getVolumeSize() const;
	int numRow() const;
public:
	// traverse N-dimension position.
	// 多次元バッファ上の座標更新
	// 0~N-1次元のベクトルを メモリ配置順に巡回する
	// 巡回時のオフセット移動をする次元を指定可能
	bool traverseShape(NglVoxelPosition& pos, int moveDimension) const;
	// calc element index from N-dimension position.
	// シェイプと座標から要素インデックスを計算
	int calcIndex(const NglVoxelPosition& pos) const;

	// is pos in this shape.
	// シェイプに収まっているか
	bool isInner(const NglVoxelPosition& pos) const;
protected:
	void recalcSize();

private:
	TArray<int>	shape_;
	int			size_;
	// size_ / 0-dim-size
	int			numRow_;
};
//
// CNN layer
//	number of kernel is calculated from input and output shape.
//	i.e.
//		input shape = { 32,32 }
//		output shape = { 32,32, 3, 2 }
//		number of kernel is 3*2 = 6.
//  
//
class NglCnnLayer : public NglNeuralNetworkLayerBase
{
public:
	enum EBUFFER_KIND : int
	{
		BK_INPUT = 0,
		BK_OUTPUT,
		BK_KERNEL,

		BK_INPUT_WITH_PADDING,
		BK_KERNEL_RADIUS,// for save CNN parameter.

		EBUFFER_KIND_MAX
	};

public:
	NglCnnLayer();
	~NglCnnLayer();

	// setup layer.
	// kernelRadiusShape is filter radius. radius 1 -> 1x1 filter. radius 2 -> 3x3 filter. radius 3 -> 5x5 filter.
	// 0-radius is treated internally as 1.
	//	number of kernel is calculated from input and output shape.
	//		input shape = { 32,32 }
	//		output shape = { 32,32, 3, 2 }
	//		number of kernel is 3*2 = 6.
	// カーネル半径を指定する.内部的に奇数サイズのカーネルとしたいためこのようにしている.
	// カーネル半径1 -> 1x1, カーネル半径2 -> 3x3, カーネル半径3 -> 5x5 となる。
	// カーネル半径0は1扱いとなる
	bool Initialize(unsigned int* inputShape, unsigned int inputShapeSize, unsigned int* outputShape, unsigned int outputShapeSize, 
		unsigned int* kernelRadiusShape, unsigned int kernelRadiusShapeSize,
		unsigned int* strideShape, unsigned int strideShapeSize);

	// calc layer neuron activity with forward
	// CNN is reshape input-buffer to own shape.
	void Forward(const float* input, unsigned int size);

	// Call at change mode. Train-Mode is True, Inference-Mode is False.
	// ネットワークの学習モードと推論モードを切り替え. デフォルトはメモリ使用量の少ない推論モード
	// change network mode with Train or Inference. default is Inference for reasons of low memory usage.
	void OnChangeTrainMode(bool toTrainMode);

	// ----------------------------------------------------------------------------------------------------------------
	// getter
	const TArray<int>& GetInputShape() const { return shape_[BK_INPUT].getDimensionSizeArray(); }
	const TArray<int>& GetOutputShape() const { return shape_[BK_OUTPUT].getDimensionSizeArray(); }
	const TArray<int>& GetKernelRadius() const { return shape_[BK_KERNEL_RADIUS].getDimensionSizeArray(); }
	const TArray<int>& GetStride() const { return stride_.getPosition(); }

	// ----------------------------------------------------------------------------------------------------------------
	// for Training Method.
	//
	// init weight by random.
	void InitializeWeightWithNormalDistribution();

	// BackPropagation. add learcning delta to update-matrix. practical update is UpdateWeight().
	// 逆伝搬. 引数は出力側から伝搬してきた勾配ベクトル( レイヤの出力ニューロン数と一致 )
	// 重み行列の更新値にデルタを足しこみ、前のレイヤへ伝搬する勾配を計算する.
	// 実際の重み行列の更新はUpdateWeight()を実行することで処理される.
	void BackPropagation(const float* backPropGradient, unsigned int size);

public:

protected:

private:
	// weight index offset to each kernel.
	TArray<unsigned int>	kernelWeightOffsets_;
	// num cnn-filter. cnnのフィルタ数.
	int			numKernel_;

	// input work buffer contains padding.
	TArray<float>			inputWork_;



	NglShape				shape_[EBUFFER_KIND_MAX];
	NglVoxelPosition		stride_;
	// padding. head and tail.
	NglVoxelPosition		padding_[2];
};





//--------------------------------------------------------
// Simple Stack Based Neural Network. シンプルなニューラルネットワーク
class NglSimpleLayerStackNN
{
public:

public:
	NglSimpleLayerStackNN();
	~NglSimpleLayerStackNN();

	void Cleanup();

	// Add Layer.
	// レイヤを追加
	bool AddLayer(const TSharedPtr<NglNeuralNetworkLayerBase>& newLayer);

	// calculate NeuralNetwork Output.
	// Output Result is [GetActivation]
	// 入力を与えてネットワークの順伝搬計算. 結果はGetActivity()で取得可能
	void Forward(const TArray<float>& input);

	// getter
	unsigned int NumLayer() const;
	unsigned int NumLayerNeuron(unsigned int layer) const;

	// get input layer neuron count.
	// 入力レイヤのニューロン数
	unsigned int NumInputLayerNeuron() const;
	// get input layer neuron count.
	// 出力レイヤのニューロン数
	unsigned int NumOutputLayerNeuron() const;

	const float* GetActivities(unsigned int layer) const;
	float* GetActivities(unsigned int layer);
	const float* GetOutputActivities() const;
	float* GetOutputActivities();

	// get neuron Activity that is result by CalcForward().
	// 前回実行されたCalcForward()で更新されたニューロンの活性状態を取得する
	float GetActivity(unsigned int layer, unsigned int neuron) const;
	// get output.
	float GetOutputActivity(unsigned int neuron) const;


	// change network mode with Train or Inference. default is Inference for reasons of low memory usage.
	// ネットワークの学習モードと推論モードを切り替え. デフォルトはメモリ使用量の少ない推論モード
	void SetToTrainMode();
	void SetToInferenceMode();
	bool IsTrainMode() const { return isTrainMode_; }

	void SetGradientCheckingEnable(bool v);

	// reset inner state. when restart game, call this function to clear previous influence.
	// レイヤの内部状態をリセット. RNNを含む場合にはリスタート時にこれを呼ぶことでそれ以前の状態の影響を除去できる.
	void ResetInnerState();

	// for Layer that have inner state like RNN, change state update control flag.
	// RNNのような内部状態を持つレイヤの更新を停止する. gradient-checkingの際などに利用される.
	void SetInnerStateUpdatable(bool flag);

	// ---------------------------------------------------------------------------------------------------
	// for Training Method.
	//
	// Learning Rate. 学習率.
	void SetLearningRate(float rate);
	float GetLearningRate() const { return learningRate_; }
	// Learning Momentum. 学習慣性.
	void SetLearningMomentum(float m);
	float GetLearningMomentum() const { return learningMomentum_; }
	// Regularization rate
	void SetL2RegularizationRate(float rate);
	float GetL2RegularizationRate() const { return l2RegularizationRate; }
	// Weight Delta Buffering Count.
	void SetMiniBatchSize(int count) { miniBatchSize_ = FMath::Max(1, count); }
	int GetMiniBatchSize() const { return miniBatchSize_; }

	// Set Cost Function for learning.
	// コスト関数をセット
	void SetCostFunction(const TSharedPtr<NglCostFuncBase>& costFunc);
	// 最期に実行した学習時のコスト関数の値
	float GetLastTrainCost() const { return lastTrainCostValue_; }
	// train. need input-data and output-teach-data. analyticDifference is destination of backProp Difference Check.
	// 学習.
	void Train(const TArray<float>& input, const TArray<float>& teacher);

protected:
	// train. need input-data and output-teach-data. analyticDifference is destination of backProp Difference Check.
	// 学習.
	void _Train(const TArray<float>& input, const TArray<float>& teacher, TArray<float>* outAnalyticDifference = NULL);
	// gradient checking	
	void _TrainWithGradientChecking(const TArray<float>& input, const TArray<float>& teacher);

	bool IsValidLayerNeuron(unsigned int layer, unsigned int neuron) const;

protected:
	// layer holder.
	TArray<TSharedPtr<NglNeuralNetworkLayerBase>>	layers_;

	bool isTrainMode_;

	// ---------------------------------------------------------------------------------------------------
	// for Training Member.
	//
	// cost Function. コスト関数
	TSharedPtr<NglCostFuncBase>					costFunc_;
	// cost value of last learning. 最期に実行した学習時のコスト関数の値
	float										lastTrainCostValue_;
	// learning rate. 学習率. 
	float										learningRate_;
	// momentum. 学習慣性. 
	float										learningMomentum_;
	// L2 Regularization rate. L2正則化係数. 
	float										l2RegularizationRate;
	// minibatch size. Number of buffering until weight delta is applied. ミニバッチサイズ. ウェイト更新差分をウェイトに反映するまでの回数.
	int											miniBatchSize_;
	// counter.
	int											miniBatchAddCounter_;

	// for gradient checking.
	bool										gradientCheckingEnable_;
	TArray<int>									weightLayerOffset_;
	TArray<float>								weightAnalyticDifference_;
	TArray<float>								weightNumericalDifference_;

	// ---------------------------------------------------------------------------------------------------
};
//--------------------------------------------------------


/**
 * 
 */
class NGLNN_API NglNeuralNetworkCore
{
public:
	NglNeuralNetworkCore();
	~NglNeuralNetworkCore();
};
