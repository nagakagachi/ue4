﻿/*
	Copyright (c) 2018 Taro Horikawa

	twitter@nagakagachi
*/

#include "NglSimpleLayerStackNN.h"

#include "FileHelper.h"
#include "Json.h"
#include "Paths.h"


// file path fix
static FString generateJsonPath(const FString& filePath, const FString& baseDirPath)
{
	if (0 >= filePath.Len())
		return FString("");
	FString dirPath, fileName, extension;
	FPaths::Split(filePath, dirPath, fileName, extension);
	if (0 >= fileName.Len())
		return FString("");
	if (0 >= dirPath.Len())
		dirPath = baseDirPath;// base of relative path is SaveDir.
	else
		dirPath += TEXT("/");// add /
	if (0 >= extension.Len())
		extension = TEXT("json");
	// fixed File Path
	return dirPath + fileName + TEXT(".") + extension;
}


UNglSimpleLayerStackNN::UNglSimpleLayerStackNN()
{

#if 0
	// GRUテスト

	NglSimpleLayerStackNN testNN;
	testNN.SetToTrainMode();

#if 1
	TSharedPtr< NglAffineLayer > gruLayer0(new NglAffineLayer());
	gruLayer0->Initialize(1, 4);
	gruLayer0->InitializeWeightWithNormalDistribution();
	testNN.AddLayer(gruLayer0);
#endif
#if 1
	TSharedPtr< NglTanhLayer > tanhLayer0(new NglTanhLayer());
	tanhLayer0->Initialize(4);
	testNN.AddLayer(tanhLayer0);
#endif

	TSharedPtr< NglGruLayer > gruLayer1(new NglGruLayer());
	gruLayer1->Initialize(4, 1);
	gruLayer1->InitializeWeightWithNormalDistribution();
	testNN.AddLayer(gruLayer1);


	const int MAX_CNT = 500;
	for (int i = 0; i < MAX_CNT; ++i)
	{
		for (int timeStep = 0; timeStep <= 360; ++timeStep)
		{
			float t1 = FMath::DegreesToRadians(float(timeStep));
			TArray<float> inputData({ t1 });
			TArray<float> teachData({ FMath::Cos(t1) });

			//testNN.TrainWithGradientChecking(inputData, teachData);
			testNN.Train(inputData, teachData);

			//UE_LOG(LogTemp, Log, TEXT("[TEST][GRU COST] %f."), testNN.GetLastTrainCost());

		}
		// 内部状態リセットのテスト
		testNN.ResetInnerState();
	}

	testNN.SetToInferenceMode();
#endif

}

// Destruct
void UNglSimpleLayerStackNN::BeginDestroy()
{
	Super::BeginDestroy();
}


void UNglSimpleLayerStackNN::AddLayer(UNglNeuralNetworkLayerBase* layer)
{
	if (nullptr == layer)
		return;
	if (nullptr == layer->GetLayer().Get())
	{
		UE_LOG(LogTemp, Log, TEXT("[ERROR][UNglSimpleLayerStackNN][AddLayer] Layer is NULL."));
		return;
	}
	// add layer object holder
	layers_.Add(layer);
	// add layer to nn core
	nn_.AddLayer(layer->GetLayer());
}

void UNglSimpleLayerStackNN::Train(const TArray<float>& input, const TArray<float>& teach, bool gradientCheckingEnable)
{
	if (gradientCheckingEnable)
		nn_.TrainWithGradientChecking(input, teach);
	else
		nn_.Train(input, teach);
}

void UNglSimpleLayerStackNN::Forward(const TArray<float>& input)
{
	nn_.Forward(input);
}

bool UNglSimpleLayerStackNN::SaveJson(const FString& inputFilePath)
{
	if (0 >= inputFilePath.Len())
		return false;
	const FString filePath = generateJsonPath(inputFilePath, FPaths::ProjectSavedDir());

	TSharedPtr<FJsonObject> JsonObjectRoot(new FJsonObject);

	// ----------------------------------------------------------------------------------------------------
	// 情報設定
	// 念のためネットワーククラスの名前を保存しておく
	JsonObjectRoot->SetStringField("ClassName", StaticClass()->GetName());
	{
		// Json Object Array
		// Arrayとしてフィールド追加するためには JsonValue派生クラスのArrayである必要がある
		TArray< TSharedPtr<FJsonValue> > ObjArray;
		for (int li = 0; li < layers_.Num(); ++li)
		{
			// 実体として FJsonObject であるようなValueラッパー FJsonValueObject を作ってそれをArrayに追加する
			auto newChild = TSharedPtr<FJsonValueObject>(new FJsonValueObject(TSharedPtr<FJsonObject>(new FJsonObject())));
			{
				TSharedPtr<FJsonObject> layerJsonObj = newChild->AsObject();
				{
					layers_[li]->SaveJsonEntry(layerJsonObj.Get());
				}
			}
			ObjArray.Add(newChild);
		}
		JsonObjectRoot->SetArrayField("LayerArray", ObjArray);
	}
	// ----------------------------------------------------------------------------------------------------

	FString writeData = "";
	// writeData をバッファとしてJsonWriter作成
	TSharedRef< TJsonWriter<> > Writer = TJsonWriterFactory<>::Create(&writeData);
	// JsonWriterでJsonObjectをバッファに書き込み
	FJsonSerializer::Serialize(JsonObjectRoot.ToSharedRef(), Writer);
	// バッファをfileへ出力
	FFileHelper::SaveStringToFile(writeData, filePath.GetCharArray().GetData());

	return false;
}

bool UNglSimpleLayerStackNN::LoadJson(const FString& inputFilePath)
{
	// reset
	Cleanup();

	if (0 >= inputFilePath.Len())
		return false;
	const FString filePath = generateJsonPath(inputFilePath, FPaths::ProjectSavedDir());

	TSharedPtr<FJsonObject> JsonObjectRoot(new FJsonObject);

	FString readData = "";
	if (!FFileHelper::LoadFileToString(readData, filePath.GetCharArray().GetData()))
		return false;
	// ファイル読み取り
	TSharedRef< TJsonReader<> > Reader = TJsonReaderFactory<>::Create(readData);
	// デシリアライズ
	if (!FJsonSerializer::Deserialize(Reader, JsonObjectRoot))
		return false;

	// ----------------------------------------------------------------------------------------------------
	// 情報取り出し

	// 念のためクラス名が一致しているか
	FString className;
	if (!JsonObjectRoot->TryGetStringField("ClassName", className) || StaticClass()->GetName() != className)
	{
		// クラス名フィールドが無いまたは一致しない
		// 警告を出すだけにするか...
		UE_LOG(LogTemp, Log, TEXT("[ERROR][UNglSimpleLayerStackNN][LoadJson] Json Class Name Field is Not Found or Not Match."));
	}

	const TArray< TSharedPtr<FJsonValue> > *layerArrayJson;
	if (JsonObjectRoot->TryGetArrayField("LayerArray", layerArrayJson))
	{
		for (const auto& layerJson : *layerArrayJson)
		{
			const TSharedPtr<FJsonObject> *jo;
			if (layerJson->TryGetObject(jo))
			{
				UNglNeuralNetworkLayerBase* newLayer =
					NglNeuralNetworkClassCatalog::GetInstance().CallLayerCreateFunc(jo->Get()->GetStringField("LayerType"));
				if (newLayer)
				{
					// setup by json
					if (!newLayer->LoadJsonEntry(jo->Get()))
					{
						// Failed
						delete newLayer;
					}
					else
					{
						// success
						AddLayer(newLayer);
					}
				}
			}
		}
	}
	// ----------------------------------------------------------------------------------------------------

	return true;
}