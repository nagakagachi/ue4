﻿/*
	Copyright (c) 2018 Taro Horikawa

	twitter@nagakagachi
*/

#include "NglNeuralNetworkComponents.h"


#include "Json.h"


// Entry Point of Save to Json.
bool UNglNeuralNetworkLayerBase::SaveJsonEntry(FJsonObject* jsonObject) const
{
	if (!jsonObject)
		return false;

	// base parameters
	//jsonObject->SetStringField("LayerType", StaticClass()->GetName());
	jsonObject->SetStringField("LayerType",  GetClass()->GetName());
	jsonObject->SetNumberField("NumInput", layerBase_->NumInput());
	jsonObject->SetNumberField("NumOutput", layerBase_->NumOutput());

	// Weights
	TArray< TSharedPtr<FJsonValue> > weightArrayJson;
	for (const auto& w : layerBase_->GetWeight())
	{
		weightArrayJson.Add(MakeShareable<FJsonValueNumber>(new FJsonValueNumber(w)));
	}
	jsonObject->SetArrayField("Weights", weightArrayJson);

	// Call Inherit class Save-Json
	return SaveJson(jsonObject);
}
// Entry Point of Load from Json..
bool UNglNeuralNetworkLayerBase::LoadJsonEntry(const FJsonObject* jsonObject)
{
	if (!jsonObject)
		return false;

	NglNeuralNetworkBaseInitializer initializer;
	initializer.numInput_ = jsonObject->GetNumberField("NumInput");
	initializer.numOutput_ = jsonObject->GetNumberField("NumOutput");

	// Call Inherit class Load-Json
	if (!LoadJson(jsonObject, initializer))
		return false;

	// setup weight
	const TArray< TSharedPtr<FJsonValue> > *weightJson;
	if (jsonObject->TryGetArrayField("Weights", weightJson))
	{
		TArray<float> weights;
		weights.SetNumZeroed(weightJson->Num()); // resize
		int numW = weightJson->Num();
		const TSharedPtr<FJsonValue>* ptrW = weightJson->GetData();
		for (int iw = 0; iw < numW; ++iw)
		{
			weights[iw] = ptrW[iw]->AsNumber();
		}
		// set weight
		layerBase_->SetWeight(weights.GetData(), weights.Num(), true);
	}
	return true;
}
// --------------------------------------------------------------------------------------




// --------------------------------------------------------------------------------------
// load json
bool UNglReluLayer::LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer)
{
	if (!jsonObject)
		return false;
	// 初期化
	Initialize(initializer.numInput_);
	return true;
}
// load json
bool UNglSigmoidLayer::LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer)
{
	if (!jsonObject)
		return false;
	// 初期化
	Initialize(initializer.numInput_);
	return true;
}
// load json
bool UNglTanhLayer::LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer)
{
	if (!jsonObject)
		return false;
	// 初期化
	Initialize(initializer.numInput_);
	return true;
}
// load json
bool UNglSoftplusLayer::LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer)
{
	if (!jsonObject)
		return false;
	// 初期化
	Initialize(initializer.numInput_);
	return true;
}
// load json
bool UNglSoftmaxLayer::LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer)
{
	if (!jsonObject)
		return false;
	// 初期化
	Initialize(initializer.numInput_);
	return true;
}

// load json
bool UNglAffineLayer::LoadJson( const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer)
{
	if (!jsonObject)
		return false;
	// 初期化
	Initialize(initializer.numInput_, initializer.numOutput_, false);
	return true;
}
// load json
bool UNglGruLayer::LoadJson(const FJsonObject* jsonObject, const NglNeuralNetworkBaseInitializer& initializer)
{
	if (!jsonObject)
		return false;
	// 初期化
	Initialize(initializer.numInput_, initializer.numOutput_, false);
	return true;
}
// --------------------------------------------------------------------------------------




// ----------------------------------------------------------------------------------------------------------------------------------------
NglNeuralNetworkClassCatalog& NglNeuralNetworkClassCatalog::GetInstance()
{
	static NglNeuralNetworkClassCatalog instance;
	return instance;
}

bool NglNeuralNetworkClassCatalog::AddLayerCreateFunc(const FString& className, UNglNeuralNetworkLayerBase* (*static_self_create_method)())
{
	if (layerCreateFuncMap_.Contains(className))
		return false;
	// register delegate object. std::function not work.
	// std::functionはTMapが要素のメモリ再配置をする関係でthisポインタが壊れるため使えない. TUniquePtrかデリゲートを利用する.
	NglNeuralNetworkLayerCreateDelegate newDelegete;
	newDelegete.BindStatic(static_self_create_method);
	layerCreateFuncMap_.Add(className, newDelegete);
	return layerCreateFuncMap_.Contains(className);
}
// call Layer Create Func
/*
	TSharedPtr<UNglNeuralNetworkLayerBase> createTest(
	NglNeuralNetworkClassCatalog::GetInstance().CallLayerCreateFunc(layers_[li]->GetClass()->GetName())
	);
*/
UNglNeuralNetworkLayerBase* NglNeuralNetworkClassCatalog::CallLayerCreateFunc(const FString& className)
{
	if (!layerCreateFuncMap_.Contains(className))
		return nullptr;
	return layerCreateFuncMap_[className].Execute();
}

NglNeuralNetworkClassCatalog::NglNeuralNetworkClassCatalog()
{
	// default register layers.
	// 既定で用意したレイヤに関してはこちらで登録してしまおう
	
	// ReLU
	AddLayerCreateFunc(UNglReluLayer::StaticClass()->GetName(), UNglReluLayer::Create);
	// Sigmoid
	AddLayerCreateFunc(UNglSigmoidLayer::StaticClass()->GetName(), UNglSigmoidLayer::Create);
	// Tanh
	AddLayerCreateFunc(UNglTanhLayer::StaticClass()->GetName(), UNglTanhLayer::Create);
	// Softplus
	AddLayerCreateFunc(UNglSoftplusLayer::StaticClass()->GetName(), UNglSoftplusLayer::Create);

	// Softmax
	AddLayerCreateFunc(UNglSoftmaxLayer::StaticClass()->GetName(), UNglSoftmaxLayer::Create);

	// Affine
	AddLayerCreateFunc(UNglAffineLayer::StaticClass()->GetName(), UNglAffineLayer::Create);

	// GRU
	AddLayerCreateFunc(UNglGruLayer::StaticClass()->GetName(), UNglGruLayer::Create);

}
NglNeuralNetworkClassCatalog::~NglNeuralNetworkClassCatalog()
{
	// destroy
}
// ----------------------------------------------------------------------------------------------------------------------------------------


/*
// Sets default values
ANglNeuralNetworkComponents::ANglNeuralNetworkComponents()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ANglNeuralNetworkComponents::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ANglNeuralNetworkComponents::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

*/