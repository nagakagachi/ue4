﻿/*
	Copyright (c) 2018 Taro Horikawa

	twitter@nagakagachi
*/
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"

#include "NglNeuralNetworkCore.h"

#include "NglNeuralNetworkFunction.generated.h"

// ブループリントへの公開
// 二重数
USTRUCT(BlueprintType)
struct FNglDualNumber
{
	GENERATED_USTRUCT_BODY()
public:
	FNglDualNumber()
	{}
	FNglDualNumber(float val)
		: dn_(val)
	{
	}
	FNglDualNumber(const NglDualNumber& val)
		: dn_(val)
	{
	}

	NglDualNumber dn_;
};


/**
 * 
 */
UCLASS()
class NGLNN_API UNglNeuralNetworkFunction : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
	
	// 演算の公開
	// -------------------------------------------------------------------
	// 二重数
	UFUNCTION(BlueprintPure)
	static FNglDualNumber GenDualNumber(
			float arg0)
	{
		return FNglDualNumber(arg0);
	}
	UFUNCTION(BlueprintPure)
	static FNglDualNumber Add( 
		const FNglDualNumber& arg0,
		const FNglDualNumber& arg1)
	{
		return FNglDualNumber( (arg0.dn_ + arg1.dn_) );
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Multiply(
			const FNglDualNumber& arg0,
			const FNglDualNumber& arg1)
	{
		return FNglDualNumber((arg0.dn_ * arg1.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Divide(
			const FNglDualNumber& arg0,
			const FNglDualNumber& arg1)
	{
		return FNglDualNumber((arg0.dn_ / arg1.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Sin(
			const FNglDualNumber& arg0)
	{
		return FNglDualNumber(NglDualNumber::sin(arg0.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Cos(
			const FNglDualNumber& arg0)
	{
		return FNglDualNumber(NglDualNumber::cos(arg0.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Tan(
			const FNglDualNumber& arg0)
	{
		return FNglDualNumber(NglDualNumber::tan(arg0.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Exp(
			const FNglDualNumber& arg0)
	{
		return FNglDualNumber(NglDualNumber::exp(arg0.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Loge(
			const FNglDualNumber& arg0)
	{
		return FNglDualNumber(NglDualNumber::loge(arg0.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Log2(
			const FNglDualNumber& arg0)
	{
		return FNglDualNumber(NglDualNumber::log2(arg0.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Sqrt(
			const FNglDualNumber& arg0)
	{
		return FNglDualNumber(NglDualNumber::sqrt(arg0.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Pow(
			const FNglDualNumber& arg0,
			const FNglDualNumber& arg1)
	{
		return FNglDualNumber(NglDualNumber::pow(arg0.dn_, arg1.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Abs(
			const FNglDualNumber& arg0)
	{
		return FNglDualNumber(NglDualNumber::abs(arg0.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Max(
			const FNglDualNumber& arg0,
			const FNglDualNumber& arg1)
	{
		return FNglDualNumber(NglDualNumber::max(arg0.dn_, arg1.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Min(
			const FNglDualNumber& arg0,
			const FNglDualNumber& arg1)
	{
		return FNglDualNumber(NglDualNumber::min(arg0.dn_, arg1.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber Sigmoid(
			const FNglDualNumber& arg0)
	{
		return FNglDualNumber(NglDualNumber::sigmoid(arg0.dn_));
	}
	UFUNCTION(BlueprintPure)
		static FNglDualNumber ReLU(
			const FNglDualNumber& arg0)
	{
		return FNglDualNumber(NglDualNumber::ReLU(arg0.dn_));
	}
	// Get Value part of Dual Number.
	UFUNCTION(BlueprintPure)
		static float GetValue(
			const FNglDualNumber& arg0)
	{
		return arg0.dn_.Value();
	}
	// Get Differential part of Dual Number.
	UFUNCTION(BlueprintPure)
		static float GetDifferential(
			const FNglDualNumber& arg0)
	{
		return arg0.dn_.Differential();
	}
	// -------------------------------------------------------------------
	
};
