﻿/*
	Copyright (c) 2018 Taro Horikawa

	twitter@nagakagachi
*/

#include "NglNeuralNetworkFunction.h"




